<?php include('includes/header.php'); ?>

<?php if(isset($_GET['slug'])){ ?>
<div class="container">
<div class="inner_content cus_zindex"> 
	<div class="col-md-6 col-sm-12 col-xs-12">
		<?php 
		if($companydata['description'] != ''){ 
			echo htmlspecialchars_decode(stripslashes($companydata['description']));
		}else{ ?>
			<div class="inner_easy_left">
			<div class="text-center">
				<h4>It's As Easy As 1 - 2 - 3</h4>
			</div>	
				<div class="row common_easyway">
					<div class="col-md-5 col-sm-5 col-xs-5 wd100_xs">
						<div class="easy_left_img">
							<img src="img/simply_img.jpg" alt="">
						</div>
					</div>
					<div class="col-md-7 col-sm-7 col-xs-7 wd100_xs">
						<div class="easy_rgt_txt">
							<span>1</span>
							<h3>Simply</h3>
							<p>Browse as usual nd see our deals appear </p>
						</div>
					</div>  
				</div>
				<div class="row common_easyway">
					<div class="col-md-5 col-sm-5 col-xs-5 wd100_xs">
						<div class="easy_left_img">
							<img src="img/more_img.jpg" alt="">
						</div>
					</div>
					<div class="col-md-7 col-sm-7 col-xs-7 wd100_xs">
						<div class="easy_rgt_txt">
							<span>2</span>
							<h3>More</h3>
							<p>Your favourite brands with great savings</p>
						</div>
					</div>
				</div>
				<div class="row common_easyway"> 
					<div class="col-md-5 col-sm-5 col-xs-5 wd100_xs">
							<div class="easy_left_img">
							<img src="img/rewarding_img.jpg" alt="">
						</div>
					</div>
					<div class="col-md-7 col-sm-7 col-xs-7 wd100_xs">
						<div class="easy_rgt_txt">
							<span>3</span>
							<h3>Rewarding</h3>
							<p>Get Cashback</p>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
	<div class="col-md-6 col-sm-12 col-xs-12 border_line">
		<div class="inner_form_rgt">
			<div class="text-center">
				<h4><?php if($companydata['form_title'] != ''){ echo $companydata['form_title']; } else{ ?>JOIN AVAZ TODAY <?php } ?></h4>
				<p><?php if($companydata['form_description'] != ''){ echo $companydata['form_description']; } else{ ?>JOIN AVAZ TODAY <?php } ?></p>
			</div>
			<form class="" id="join_avaj" action="<?php echo SITEURL.'controller/signup.php'; ?>" method="post">
			<input type="hidden" value="<?php echo $slug; ?>" name="companyid">
			<?php
				if(isset($_SESSION['successf'])){
					echo '<p class="alert alert-success">'.$_SESSION['successf'].'</p>';
					unset($_SESSION['successf']);
				}else if(isset($_SESSION['failuref'])){
					echo '<p class="alert alert-danger">'.$_SESSION['failuref'].'</p>';
					unset($_SESSION['failuref']);
				}
			?>
				<div class="form-group">
					<label>First Name</label>
					<input type="text" name="first_name" class="form-control" placeholder="Please Enter Your First Name" />
				</div>
				<div class="form-group">
					<label>Last Name</label>
					<input type="text" name="sur_name" class="form-control" placeholder="Please Enter Your Surname" />
				</div>
				<div class="form-group">
					<label>Email</label>
					<input required type="email" name="av_email" class="form-control" placeholder="Please Enter Your Email" />
				</div>
				<div class="form-group">
					<label>Phone Number</label>
					<input required type="text" id="av_phone" name="av_phone" class="form-control" size="20" placeholder="Please Enter Your Phone Number" />
				</div>
				<div class="form-group">
					<label>Post Code</label>
					<input required type="text" name="av_post_code" class="form-control" placeholder="Please Enter Your Post Code" />
				</div>
				<?php if(!empty($companyquestiondata)){ for($is =0; $is< count($companyquestiondata); $is++){?>
				<div class="form-group">
					<label><?php echo $companyquestiondata[$is]['question_name']; ?></label>
					<select required class="form-control" name="av_question1[<?php echo $companyquestiondata[$is]['question_name']; ?>]">
						<option value="">Please Select</option>
						<?php for($i =0; $i< count($companyquestionoptiondata[$is]); $i++){ ?>
						<option value="<?php echo $companyquestionoptiondata[$is][$i]['question_option']; ?>"><?php echo $companyquestionoptiondata[$is][$i]['question_value']; ?></option>
						<?php } ?>
					</select>
				</div>
				<?php } } ?>
				<?php for($i =0; $i< count($companydata['question_info']); $i++){?>
					<div class="form-group">
					<label><?php echo $companydata['question_info'][$i]['question_name']; ?></label>
					<input required type="text" name="av_question2[<?php echo $companydata['question_info'][$i]['question_name']; ?>]" class="form-control" placeholder="Please Enter Your Answer" />
				</div>
				<?php } ?>
				
				<div class="form-group text-center">
					<input type="submit" name="join_avaz" class="submit_btn" Value="Submit" />
				</div>
			</form> 
		</div>	
	</div>
	<div class="clearfix"></div>
	</div> 
	</div>	
<?php }else{
	?> 
	<div class="container-fluid pad0">
			<div class="inner_content cus_zindex full-slider"> 
			<?php include('includes/section_carousel.php'); ?>
		</div>
	</div>
	<?php
} ?>

<div class="container"> 	
<?php include('includes/footer.php'); ?>
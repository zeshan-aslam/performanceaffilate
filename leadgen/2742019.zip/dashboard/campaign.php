<?php $postid = isset($_GET['cid']) ? $_GET['cid'] : -1; ?>
<div class="card strpied-tabled-with-hover">
	<div class="card-body"> 
		<div class="row">
			<div class="col-md-12">
				<?php if(isset($_SESSION['faliureerror'])){ ?>
					<p class="alert alert-danger"><?php echo $_SESSION['faliureerror']; ?></p>
				<?php unset($_SESSION['faliureerror']);	 } ?>
				<p align="left">
					<a href="<?php echo LEADURL;?>index.php/?Act=add_compaign&campid=<?=$postid?>"><b>Add Compaign</b></a>&nbsp;&nbsp;&nbsp;
				</p>	
				<div class="table-full-width table-responsive">
					<table class="table table-hover table-striped coupon_table">
						<thead> 
							<tr>
								<th>Compaign Name</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php
						
						if(get_user_info($leadgenid,'av_campaign_status',true) == 'approve'){
							$comaign = unserialize(get_user_info($leadgenid,'av_campaign',true));
							$sql = select("company","user_id = '$leadgenid'");
							while($row = fetch($sql)){
								$usercamp[] = $row['id'];
							}
								$newarray = array_merge($comaign,$usercamp);
								foreach($newarray as $value){
									$sql = select("company", "id = '$value'");
									$com = fetch($sql);
								?>
									<tr>
										<td><?php echo $com['company_name']; ?></td>
										<td><?php if($com['status'] == 1){ echo 'Active'; }else if($com['status'] == 2){ echo 'suspended'; }else{ echo 'Waiting Approval';	} ?></td>
										<td><a target="_blank" href="<?php echo SITEURL.$com['company_slug']; ?>">View</a> <?php if($leadgenid == $com['user_id']){ ?> | <a href="<?php echo LEADURL;?>index.php/?Act=add_compaign&action=edit&campid=<?=$com['id']?>">Edit</a> <?php } ?></td>
									</tr>
								<?php 
								} 
							}else{
							?>
							<tr><td colspan="2">No Record Found</td></tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div> 
		</div> 
	</div> 
</div>
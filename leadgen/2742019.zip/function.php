<?php
function connect($host, $user, $pass, $database){
	$connect = mysqli_connect($host, $user, $pass,$database);
	if (mysqli_connect_errno())
	  {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die;
	  }else{
		  return $connect;
	  } 
}



function login($con,$user, $password, $type) {
	global $prefix;
	$success = false;
	$tbl = $prefix."users";
	$pass = md5($password);
	if($type=='admin')
	{
		$typ = '1';
		 $query = "select * from $tbl where email='$user' and password='$pass' and type='$typ' and status='1'";
	}
	else
	{
		$typ = '3';
		$query = "select * from $tbl where email='$user' and password='$pass' and type='$typ' and status='1'";
	}
	$userlogin = mysqli_query($con,$query);
	if(mysqli_num_rows($userlogin) > 0)
	{
		$tbllog = $prefix."user_log";
		$fetchuser = fetch($userlogin);
		$userid = $fetchuser['id'];
		$ip = $_SERVER['REMOTE_ADDR'];
		mysqli_query($con,"insert into $tbllog (user_id,date,ip) values ('$userid', Now(), '$ip')");
		$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$string = '';
		$length = 10;
		for ($p = 0; $p < $length; $p++) {
			$string .= $characters[mt_rand(0, strlen($characters))];
		}
		if($type == 'admin')
		{
			$random = $string; 
			$_SESSION['my_token'] = $random;
			$_SESSION[$random] = $user;
			$_SESSION['login'] = 'Login Successfully';
			redirect(ADMINURL.'index.php');
		}
		else
		{
			$random = $string;
			$_SESSION['my_front_token'] = $random;
			$_SESSION[$random] = $user;
			$_SESSION['successlogin'] = 'front Login Successfully';
			
		}
		$success = true;
	}
	
	return $success;
}

function register($con, $password, $email, $type,$key,$r = '', $inv = ''){
	global $prefix;
	$tbl = $prefix."users";
	$pass = md5($password);
	if($type == 'admin')
	{
		$typ = '1';
		$status = '1';
	}
	else
	{
		$typ = '2';
		$status = '1';
	}
	$ip = $_SERVER['REMOTE_ADDR'];
	$ins = mysqli_query($con,"insert into $tbl(email, password, status, user_type, date,rkey) values ('$email', '$pass', '$status', '$typ', NOW(),'$key')");
	$lastid = mysqli_insert_id($con);
	
	if($ins){
		$invite_code = sha1(mt_rand(1,999).time().$iemail);
		$subject = "Thanks for registration";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$message .= "Thanks for registration. please check access detail below <br> Password:".$password."<br>";  
		$message .= "Your Invitation Link: ".SITEURL."?r=".$key."&invite_code=".$invite_code;  
		mail($email, $subject, $message, $headers);
		$err=1;
	}
	else
	{
		$err = mysqli_error($con);
	}
	return $err;
}

function redirect($page){
	header('location:'.$page);
}

function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

function user(){
	if(isset($_SESSION['my_token']))
	{
		$token = $_SESSION['my_token'];
		if(isset($_SESSION[$token]))
		{
			$user = $_SESSION[$token];
		}
		else
		{
			$user = '';
		}
	}
	else
	{
		$user = '';
	}
	return $user;
}

function leadgenuser(){
	if(isset($_SESSION['my_front_token']))
	{
		$token = $_SESSION['my_front_token'];
		if(isset($_SESSION[$token]))
		{
			$user = $_SESSION[$token];
		}
		else
		{
			$user = '';
		}
	}
	else
	{
		$user = '';
	}
	return $user;
}

function logout()
{
	session_destroy();
	redirect('login.php');
}

function leadgenlogout()
{
	session_destroy();
	redirect(SITEURL);
}

function userinfo($id) {
	global $prefix;
	$fetch = '';
	if(isset($_SESSION['my_token']))
	{
		$token = $_SESSION['my_token'];
		if(isset($_SESSION[$token]))
		{
			$user = $_SESSION[$token];
			$tbl = 'users';
			$where = "email='$user'";
			$sel = select($tbl, $where);
			$row = fetch($sel);
			$fetch = $row[$id];
		}
	}
	return $fetch;
}

function leaduserinfo($id) {
	global $prefix;
	$fetch = '';
	if(isset($_SESSION['my_front_token']))
	{
		$token = $_SESSION['my_front_token'];
		if(isset($_SESSION[$token]))
		{
			$user = $_SESSION[$token];
			$tbl = 'users';
			$where = "email='$user'";
			$sel = select($tbl, $where);
			$row = fetch($sel);
			$fetch = $row[$id];
		}
	}
	return $fetch;
}

function select($tblname , $where='') {
	global $prefix,$con;
	$tbl = $prefix.$tblname;
	if($where != '')
	{
		
		$se = "select * from $tbl where $where";
		$sel = mysqli_query($con,$se);
	}
	else
	{
		$se= "select * from $tbl";
		$sel = mysqli_query($con,$se);
	}	
	return $sel;
}

function fetch($fetch){
	return mysqli_fetch_array($fetch);
}

function query($con,$query, $singleResult = 0) {

		$_result = mysqli_query($con,$query );

		if (preg_match("/select/i",$query)) {
		$result = array();
		$table = array();
		$field = array();
		$tempResults = array();
		 $numOfFields = mysqli_num_fields($_result);
			for ($i = 0; $i < $numOfFields; ++$i) {
				$table_info  = mysqli_fetch_field_direct($_result, $i);
				
				array_push($table,$table_info->table);
				array_push($field,$table_info->name);
			}

			while ($row = mysqli_fetch_row($_result)) {
				for ($i = 0;$i < $numOfFields; ++$i) {
				 $tempResults[$field[$i]] = $row[$i];
				 }
				 if ($singleResult == 1) {
		 			mysqli_free_result($_result);
					
					return $tempResults;
				}
				 array_push($result,$tempResults);
			}
			mysqli_free_result($_result);
			
			return($result);
		}
		

	}

function get_user_info($userid, $key,$echo = false){
	global $prefix,$con;
		$query = "select * from ".$prefix."usermeta where user_id = '$userid' and user_key = '$key'";
		if($echo){
			$q = query($con,$query,1);
			$result = $q['user_meta'];
		}else{
			$result = query($con,$query);
		}
		return $result;
}

function get_avaz_info($userid, $key,$echo = false){
	global $prefix,$con;
		$query = "select * from ".$prefix."joinavazmeta where user_id = '$userid' and user_key = '$key'";
		if($echo){
			$q = query($con,$query,1);
			$result = $q['user_meta'];
		}else{
			$result = query($con,$query);
		}
		return $result;
}

function get_post_meta($post_id, $key,$echo = false){
	global $prefix,$con;
		$query = "select * from ".$prefix."posts where user_id = '$post_id' and post_slug = '$key'";
		if($echo){
			$q = query($con,$query,1);
			$result = $q['post_description'];
		}else{
			$result = query($con,$query);
		}
		return $result;
}

function get_config_meta($key, $comid, $echo = false){
	global $prefix,$con;
		$query = "select * from ".$prefix."config where user_id = '$comid' and config_name = '$key'";
		if($echo){
			$q = query($con,$query,1);
			$result = $q['config_value'];
		}else{
			$result = query($con,$query);
		}
		return $result;
}

function update_post_meta($postid,$post_key,$value){
	global $prefix,$con;
		$query = "select * from ".$prefix."postmeta where post_id = '$postid' and post_key = '$post_key'";
		$result = query($con,$query,1);
		if($result){
			$success = mysqli_query($con,"update ".$prefix."postmeta set post_value = '$value' where post_id = '$postid' and post_key = '$post_key' ");
		}else{
			 $success = mysqli_query($con,"INSERT INTO ".$prefix."postmeta (post_id,post_key,post_value) VALUES ('$postid','$post_key','$value')");
		}
}

function update_option_meta($option_name,$option_value){
	global $prefix,$con;
		$query = "select * from ".$prefix."option where option_name = '$option_name'";
		$result = query($con,$query,1);
		if($result){
			$success = mysqli_query($con,"update ".$prefix."option set option_value = '$option_value' where option_name = '$option_name' ");
		}else{
			 $success = mysqli_query($con,"INSERT INTO ".$prefix."option (option_name,option_value) VALUES ('$option_name','$option_value')");
		}
		
		return $result;
}

function get_option_meta($key){
	global $prefix,$con;
		$query = "select * from ".$prefix."option where option_name = '$key'";
	
			$q = query($con,$query,1);
			$result = $q['option_value'];
		
		return $result;
}

function update_user_meta($userid,$user_key,$value){
	global $prefix, $con;
		$query = "select * from ".$prefix."usermeta where user_id = '$userid' and user_key = '$user_key'";
		$result = query($con,$query,1);
		if($result){
			$success = mysqli_query($con,"update ".$prefix."usermeta set user_meta = '$value' where user_id = '$userid' and user_key = '$user_key' ");
		}else{
			 $success = mysqli_query($con,"INSERT INTO ".$prefix."usermeta (user_id,user_key,user_meta) VALUES ('$userid','$user_key','$value')");
		}
		return $success;
}

function update_joinavaz_meta($userid,$user_key,$value){
	global $prefix, $con;
		$query = "select * from ".$prefix."joinavazmeta where user_id = '$userid' and user_key = '$user_key'";
		$result = query($con,$query,1);
		if($result){
			$success = mysqli_query($con,"update ".$prefix."joinavazmeta set user_meta = '$value' where user_id = '$userid' and user_key = '$user_key' ");
		}else{
			 $success = mysqli_query($con,"INSERT INTO ".$prefix."joinavazmeta (user_id,user_key,user_meta) VALUES ('$userid','$user_key','$value')");
		}
		return $success;
}

function insert($table,$data){
	global $prefix,$con;
	$field = '';
	$value = '';
	foreach($data as $key => $val){
		$field .= $key.','; 
		$value .= "'$val',";
	}
	
	$fields = rtrim($field,',');
	$values = rtrim($value,',');

	mysqli_query($con,"INSERT INTO ".$prefix.$table." ($fields) VALUES ($values)");
	
	return mysqli_insert_id($con);
	//return mysqli_error($this->_dbHandle);
}

function create_slug($string){
   
   global $prefix,$con;
   $slugs = array();
   $slug=preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
	$query = "SELECT * FROM ".$prefix."posts WHERE  post_slug  LIKE '".$slug."%'";
	$result = mysqli_query($con,$query);
	
	while($row = fetch($result)){
		$slugs[] = $row['post_slug'];
	}
	if(mysqli_num_rows($result) !== 0 && in_array($slug, $slugs)){
    $max = 0;

    //keep incrementing $max until a space is found
    while(in_array( ($slug . '-' . ++$max ), $slugs) );

    //update $slug with the appendage
    $slug .= '-' . $max;
	}
	
	return $slug; 

}

function exist($post_id,$table){
	global $prefix,$con;
	$exist = 0;
	$query = 'select * from '.$prefix.$table.' where `id` = \''.mysqli_real_escape_string($con,$post_id).'\'';
	$result = query($con,$query,1);
	if($result){ $exist = 1; }
	return $exist;
}

function email_exist($emailid){
	global $prefix,$con;
	$exist = 0;
	$tablename = $prefix."users";
	$query = "select * from $tablename where email = '$emailid'";
	$result = query($con,$query,1);
	if($result){ $exist = 1; }
	return $exist;
}

function word_limit($content,$position){
	$post = substr($content, 0, $position); 
	return $post;
}


function get_pagi($page,$total_pages,$limit){
	$adjacents = 0;
			if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
			$prev = $page - 1;                          //previous page is page - 1
			$next = $page + 1;                          //next page is page + 1
			 $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
			$lpm1 = $lastpage - 1; 
		 $targetpage =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
			$targetpage = preg_replace("/(page\=[0-9]+[\&]*)/", "", $targetpage); // Delete page query string.

				if($targetpage[strlen($targetpage) - 1 ] != "?"){ 
					$targetpage .= "?"; // add &
				}else{
					$targetpage .= "";
				} 
				 
			 $pagination = "";
		if($lastpage > 1)
			{   
			$pagination .= "<div class=\"pagination\"><div class=\"page_links\">";
        //previous button
        if ($page > 1) 
            $pagination.= "<a class=\"next page-numbers\" href=\"{$targetpage}page=$prev\"><</a>";
        else
            $pagination.= "<a href=\"javascript:;\" class=\"page-numbers disabled\"><</a>"; 

        //pages 
        if ($lastpage < 7 + ($adjacents * 2))    //not enough pages to bother breaking it up
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<span class=\"page-numbers current\">$counter</span>";
                else
                    $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$counter\">$counter</a>";                 
            }
        }
        elseif($lastpage > 5 + ($adjacents * 2)) //enough pages to hide some
        {
            //close to beginning; only hide later pages
            if($page < 1 + ($adjacents * 2))     
            {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"page-numbers current\">$counter</span>";
                    else
                        $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$counter\">$counter</a>";                 
                }
                $pagination.= "...";
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$lpm1\">$lpm1</a>";
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$lastpage\">$lastpage</a>";       
            }
            //in middle; hide some front and some back
            elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
            {
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=1\">1</a>";
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=2\">2</a>";
                $pagination.= "...";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"page-numbers current\">$counter</span>";
                    else
                        $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$counter\">$counter</a>";                 
                }
                $pagination.= "...";
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$lpm1\">$lpm1</a>";
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$lastpage\">$lastpage</a>";       
            }
            //close to end; only hide early pages
            else
            {
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=1\">1</a>";
                $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=2\">2</a>";
                $pagination.= "...";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
                {
                    if ($counter == $page)
                        $pagination.= "<span class=\"page-numbers current\">$counter</span>";
                    else
                        $pagination.= "<a class=\"page-numbers\" href=\"{$targetpage}page=$counter\">$counter</a>";                 
                }
            }
        }

        //next button
        if ($page < $lastpage) 
            $pagination.= "<a class=\"next page-numbers\" href=\"{$targetpage}page=$next\">></a>";
        else
            $pagination.= "<a href=\"javascript:;\" class=\"page-numbers disabled\"> > </a>";
        $pagination.= "</div></div>\n";     
    }
		return $pagination;
	}
	


function insert_post($con,$table,$data,$imagefile,$post_id = false){
	global $prefix,$con;
	$success = false;
	if(!exist($post_id,$table)){
		$lastinsertid = insert($table,$data);
		if($lastinsertid){
			$success = true;
		}
	}else{
		$fields = '';
		foreach($data as $key => $val){
			$fields .= $key."="."'".$val."'".",";
		}
		$upfields = rtrim($fields,",");
	
		$success = mysqli_query($con,"update ".$prefix.$table." set $upfields where id = '$post_id'");
	}
	return $success;
}

 function getpage(){
	  if(!isset($_GET['page'])) $page=1; //Which page to display?
	  else $page=$_GET['page'];
return $page;
}

 function date2mysql($date){
	$tmp        =explode('/',$date);
	if(count($tmp)!=3) {
	$tmp        =explode('-',$date);
	if(count($tmp)!=3) return "0000-00-00";
	}
	$date        ="$tmp[2]-$tmp[1]-$tmp[0]";
	return $date;
 }

function countaffilatesdaily($leadgenid, $leadtype){
	global $prefix,$con;
	$tablename = $prefix."affilates_charges";
	$sqlcountaffil = "select * from $tablename where user_id = '$leadgenid' and DATE(date) = DATE(NOW()) and lead_type = '$leadtype'";
	$resultaffil   = mysqli_query($con,$sqlcountaffil);
	$naff = mysqli_num_rows($resultaffil);
	return $naff;
}

function countaffilatesmonthly($leadgenid, $leadtype){
	global $prefix,$con;
	$tablename = $prefix."affilates_charges";
	$sqlimpression = mysqli_query($con,"select * from $tablename where MONTH(date) = MONTH(CURRENT_DATE()) and lead_type = '$leadtype' and user_id = '$leadgenid'");
	$naff = mysqli_num_rows($sqlimpression);
	return $naff; 
}

function countaffilatesyearly($leadgenid, $leadtype){
	global $prefix,$con;
	$tablename = $prefix."affilates_charges";
	$sqlimpression = mysqli_query($con,"select * from $tablename where YEAR(date) = YEAR(CURRENT_DATE()) and lead_type = '$leadtype' and user_id = '$leadgenid'");
	$naff = mysqli_num_rows($sqlimpression);
	return $naff; 
}

function yearlyaffilates($leadgenid, $leadtype){
	global $prefix,$con;
	$tablename = $prefix."affilates_charges";
	/*Start Yearly Record*/ 
$year = date('Y');

 $sqlcountmsale = "SELECT 
    SUM(if(MONTH(date) = 1, affilate_charges,0)) as Jan,
    SUM(if(MONTH(date) = 2, affilate_charges,0)) as Feb,
    SUM(if(MONTH(date) = 3, affilate_charges,0)) as Mar,
    SUM(if(MONTH(date) = 4, affilate_charges,0)) as Apr,
    SUM(if(MONTH(date) = 5, affilate_charges,0)) as May,
    SUM(if(MONTH(date) = 6, affilate_charges,0)) as Jun,
    SUM(if(MONTH(date) = 7, affilate_charges,0)) as Jul,
    SUM(if(MONTH(date) = 8, affilate_charges,0)) as Aug,
    SUM(if(MONTH(date) = 9, affilate_charges,0)) as Sep,
    SUM(if(MONTH(date) = 10, affilate_charges,0)) as Oct,
    SUM(if(MONTH(date) = 11, affilate_charges,0)) as Nov,
    SUM(if(MONTH(date) = 12, affilate_charges,0)) as `Dec`
FROM $tablename 
WHERE user_id = $leadgenid and YEAR(date) = '$year' 
  AND lead_type = '$leadtype'";
  $resultmlead   = mysqli_query($con,$sqlcountmsale);
  while($rowlead = mysqli_fetch_array($resultmlead)){
	  $yearsale = $rowlead;
  }
	return $yearsale;
	
}

function getWeekDates($date, $start_date, $end_date, $i) {
    $week =  date('W', strtotime($date));
    $year =  date('Y', strtotime($date));
    $from = date("Y-m-d", strtotime("{$year}-W{$week}+1")); 
    if($from < $start_date) $from = $start_date;
    $to = date("Y-m-d", strtotime("{$year}-W{$week}-7"));   
    if($to > $end_date) $to = $end_date;
	$data = array(
		'from' => $from,
		'to' => $to,
	);
    return $data;
} 

function monthlyaffilates($leadgenid, $leadtype){
	global $prefix,$con;
	$tablename = $prefix."affilates_charges";
/*Start Monthly Record*/ 
$year = date('Y');
$month = date('m');
  for($is = 0; $is < count($ids); $is++){
	$isd = $ids[$is]; 
	$psids .= "'$isd',";
  }
  $psids = rtrim($psids,',');
  
$lastmonthday = date('t');
$m = date('m');
$y = date('Y');

$sqlmsale = '';
$saledate = '';
$date = new DateTime('first Monday of this month');
$thisMonth = $date->format('m');
$weekvalue = '';
while ($date->format('m') === $thisMonth) {
    $dayweek = $date->format('Y-m-d');
	 $mno = date('d M', strtotime($dayweek));
	$sqlmsale .="SUM(if( WEEK(date)= WEEK('".$dayweek."'), affilate_charges,0)) as '".$mno."',";
    $date->modify('next Monday');
}
$month_ini = new DateTime("first day of this month");
$month_end = new DateTime("last day of this month");
$start_date = $month_ini->format('Y-m-d');
$end_date = $month_end->format('Y-m-d');
$i=1;



$sqlmsale = rtrim($sqlmsale,',');
$wsale = '';
$wlead = '';
$wclick = '';

for($date = $start_date; $date <= $end_date; $date = date('Y-m-d', strtotime($date. ' + 7 days'))) {
    $month = getWeekDates($date, $start_date, $end_date, $i);

	$weekvalue .= "'".$month['to']."',"; 
	
	$From = $month['from'];
	$To = $month['to'];
        $sqlcountmsale = "SELECT  count(*) AS reports_in_week,user_id
     FROM $tablename 
WHERE user_id = $leadgenid and date between '$From' and '$To' AND lead_type = '$leadtype'";  
$resultmsale   = mysqli_query($con,$sqlcountmsale);
while($rowws=mysqli_fetch_object($resultmsale))
{
	if($rowws->reports_in_week == ''){
		$sales = 0;
	}else{
		$sales = $rowws->reports_in_week;
	}
	$wsale .= "".$sales.","; 
} 

    $i++;
}
$data = array(
	'wsale' => $wsale,
	'weekvalue' => $weekvalue
);
return $data;
}

function is_date($date){
	$tmp        =explode('/',$date);
	if(count($tmp)!=3) {
		$tmp        =explode('-',$date);
		if(count($tmp)!=3) return 0;
	}
	if(!is_numeric($tmp[1]) || !is_numeric($tmp[0]) || !is_numeric($tmp[2]))
		return 0;
	if(checkdate($tmp[1],$tmp[0],$tmp[2])) return 1;
	else return 0;
}
?> 
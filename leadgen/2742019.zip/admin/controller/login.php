<?php
include('../../config.php');
if(isset($_POST['username']))
{
	$username = $_POST['username'];
	$pass = $_POST['password'];
	$type = "admin";
	 $result = login($con,$username, $pass, $type); 
	if(!$result){
		$_SESSION['failure'] = 'Please check your Username or Password';	
		redirect(ADMINURL.'login.php');
	}
}
?>
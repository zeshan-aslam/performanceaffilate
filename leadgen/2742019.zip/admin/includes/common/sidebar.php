<div class="am-sideleft">
      <div class="tab-content">
        <div id="mainMenu" class="tab-pane active">
          <ul class="nav am-sideleft-menu">
            <li class="nav-item">
              <a href="index.php" class="nav-link active">
                <i class="icon ion-ios-home-outline"></i>
                <span>Dashboard</span>
              </a>
            </li><!-- nav-item -->
           
			
			<li class="nav-item">
              <a href="company-new.php" class="nav-link ">
                <i class="icon ion-eye"></i>
                <span>Add Campaign</span>
              </a>
            </li><!-- nav-item -->
			<li class="nav-item">
              <a href="users.php" class="nav-link ">
                <i class="icon ion-person-stalker"></i>
                <span>Users</span>
              </a>
            </li><!-- nav-item -->
			<li class="nav-item">
              <a href="payments.php" class="nav-link ">
                <i class="icon ion-briefcase"></i>
                <span>Payments</span>
              </a>
            </li><!-- nav-item -->
          </ul>
        </div><!-- #mainMenu -->
        
      </div><!-- tab-content -->
    </div><!-- am-sideleft -->
	<div class="am-mainpanel">
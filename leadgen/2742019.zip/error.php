<?php include('includes/header.php'); ?>
<div class="container">
	<div class="inner_content cus_zindex"> 
		<div class="col-md-12 col-sm-12 col-xs-12">
			<h2>Page Not Found</h2>
		</div>
	</div>
</div>
<?php include('includes/footer.php'); ?>
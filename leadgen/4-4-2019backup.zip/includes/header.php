<?php include('config.php');
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';
$sql = select("company","company_slug='$slug'");
if($slug != ''){
	 if(mysqli_num_rows($sql) == 0){
		redirect(SITEURL);
	}  
}
$fetchpost = fetch($sql);
$comid = $fetchpost['id'];
$companydatas = unserialize(base64_decode(get_config_meta('company_data', $comid, true)));
$companydata  = unserialize($companydatas['config']);

$companyquestiondata  = unserialize($companydatas['questions']);
$companyquestionoptiondata  = unserialize($companydatas['questionoption']);
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>AVAZ - Affiliate Network</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald:400,500,600,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
<style>
.custom_navbar ul.nav li a{color: #<?php  if($companydata['link_color'] != ''){ echo $companydata['link_color']; }else{ echo 'f7931e'; } ?>;}
.custom_navbar ul.nav li a:hover, .custom_navbar ul.nav li a:focus{color: #<?php  if($companydata['link_color'] != ''){ echo $companydata['link_color']; }else{ echo 'f7931e'; } ?>;}
.inner_content .inner_form_rgt form input[type="submit"]{background: #<?php  if($companydata['form_button_color'] != ''){ echo $companydata['form_button_color']; }else{ echo 'D3D3D3'; } ?>;border: 1px solid #<?php  if($companydata['form_button_color'] != ''){ echo $companydata['form_button_color']; }else{ echo 'f7931e'; } ?>;}
.inner_content .inner_form_rgt form input[type="submit"]:hover{border: 1px solid #<?php  if($companydata['form_button_hover_color'] != ''){ echo $companydata['form_button_hover_color']; }else{ echo 'f7931e'; } ?>;background: #<?php  if($companydata['form_button_hover_color'] != ''){ echo $companydata['form_button_hover_color']; }else{ echo 'f7931e'; } ?>;}

.border_line:before {background: #<?php if($companydata['border_color'] != ''){ echo $companydata['border_color']; }else{ echo 'f7931e'; } ?> url(img/border_trans_line.png) no-repeat;}
</style>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
  </head> 
  <body>
    <div class="wrapper">
		<div class="wrap_opacity"></div>
		 <div class="container"> 
			<header class="header cus_zindex"> 				 
				 <div class="col-md-3 col-sm-3 col-xs-12 logo hidden-xs">
					<?php if($companydata['logo_name'] != ''){ $logoname = $companydata['logo_name']; }else{ $logoname = 'logo.png'; } ?>
					<a href="<?php echo SITEURL; ?>"><img style="width: 278px; height: 100px;" src="<?php echo SITEURL.'img/'.$logoname; ?>" class="img-responsive" alt="Logo"/></a>
				 </div>
				 <div class="col-md-9 col-sm-9 col-xs-12">					
					<nav class="navbar custom_navbar">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
						  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						  </button>
						 
						  <a class="navbar-brand visible-xs logo" href="#"><img src="<?php echo SITEURL.'img/logo.png'; ?>" class="img-responsive" alt="Logo"/></a>
						</div> 
						<div class="collapse navbar-collapse" style="padding-right:0px;" id="bs-example-navbar-collapse-1">
						  <ul class="nav navbar-nav link">
							<li class="active"><a href="#" data-toggle="modal" data-target="#privacy_policy">Privacy Policy</a></li>
							<li><a href="#" data-toggle="modal" data-target="#about_us">About Us</a></li>
							<li><a href="#" data-toggle="modal" data-target="#term_condition">Terms & Conditions</a></li>
							<?php if(!isset($_GET['slug'])){ ?>
							<li class="cus_btn signin_btn"><a href="#" data-toggle="modal" data-target="#sign_in">Sign In</a></li> 
							<li class="cus_btn signup_btn"><a href="<?php echo SITEURL .'signup.php'; ?>" >Sign Up</a></li>
							<?php } ?>
						  </ul>						
						</div><!-- /.navbar-collapse -->
					</nav>
				 </div>
				 <div class="clearfix"></div>
			</header>
			<div class="clearfix"></div>
	</div>
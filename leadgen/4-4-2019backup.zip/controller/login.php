<?php
include('../config.php');
if(isset($_POST['action']) && $_POST['action'] == 'sign_in'){
	$username = $_POST['username'];
	$password = $_POST['password'];
	$type = 3;
	$ok = login($con,$username, $password, $type);
	if($ok){
		echo json_encode(array('success' => true, 'url' => LEADURL.'index.php?Act=home', 'message' => 'Login successfully.'));
	}else{
		echo json_encode(array('success' => false, 'message' => 'Incorrect username/password'));
	}
	die;
}
?>
<?php
include('../config.php');
if(isset($_POST['join_avaz'])){
	unset($_POST['join_avaz']);
	$slug = $_POST['companyid'];
	$sql = select("company","company_slug='$slug'");
$fetchpost = fetch($sql);
$comid = $fetchpost['id'];
	$fields = array(
		'email' => mysqli_real_escape_string($con,$_POST['av_email']),
		'date' => date('Y-m-d h:i:s'),
		'status' => 1,
		'type' => 2,
		'companyid' => $comid,
		
	);
	$_POST['av_question1res'] = serialize($_POST['av_question1']);
		$_POST['av_question2res'] = serialize($_POST['av_question2']);
	$lastinsert_id = insert('joinavaz', $fields);
	unset($_POST['av_question1']);
	unset($_POST['av_question2']);
	unset($_POST['companyid']);
	if($lastinsert_id){
		foreach($_POST as $key => $val){
			$vals = mysqli_real_escape_string($con,$val);
			$ok = update_joinavaz_meta($lastinsert_id,$key,$vals);
		}
		$_SESSION['successf'] = "Many thanks for your time we will be in touch shortly!";
		redirect(SITEURL.$slug);
	}else{
		$_SESSION['failuref'] = mysqli_error($con);
		redirect(SITEURL.$slug);
	}
}

if(isset($_POST['sign_in'])){
	global $con;
	unset($_POST['termsCondn']);
	unset($_POST['terms']);
	unset($_POST['sign_in']);
	$email = $_POST['av_email'];
	$sql    = select('users',"email = '$email'");
	$result = mysqli_query($con,$sql);
	if(mysqli_num_rows($result)>0)
	{
	   $_SESSION['failurer'] = "Email Already Exists";
		redirect(SITEURL.'signup.php'.$slug);
		exit;
	}
	 if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){ 
			$secretKey = '6LdChJsUAAAAAPffwmu_710qnTNCt4toC7FN6t2y';
			 $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$_POST['g-recaptcha-response']); 	
			$responseData = json_decode($verifyResponse); 	
			 if(!$responseData->success){

				  $_SESSION['failurer'] = "Robot verification failed, please try again.";
					redirect(SITEURL.'signup.php'.$slug);
					exit;
			 }
		}else{
			 $_SESSION['failurer'] = 'Please check on the reCAPTCHA box.';
			 redirect(SITEURL.'signup.php'.$slug);
					exit;
			  
		}
	$today 			    = date("Y-m-d");
	$rand	=	rand(0,10000);
	$pass	=	mysqli_real_escape_string($con,$_POST['first_name'].$rand);
	$data = array(
		'email' => mysqli_real_escape_string($con,$_POST['av_email']),
		'password' => md5($pass),
		'date' => date('Y-m-d h:i:s'),
		'status' => 1,
		'type' => 3,
	);
	unset($_POST['g-recaptcha-response']);
	$lastinsert_id = insert('users', $data);
	if($lastinsert_id){
		foreach($_POST as $key => $val){
			$vals = mysqli_real_escape_string($con,$val);
			$keys = mysqli_real_escape_string($con,$key);
			$ok = update_user_meta($lastinsert_id,$keys,$vals);	
		}
			 $sqlmail		=	select("adminmail","adminmail_eventname='Merchant Registration'");
			
			 if(mysqli_num_rows($sqlmail)>0)
			{
			  $row           = mysqli_fetch_object($sqlmail);
			  $sub           = stripslashes($row->adminmail_subject);
			  $message       = stripslashes($row->adminmail_message);
			  $head          = stripslashes($row->adminmail_header);
			  $footer        = stripslashes($row->adminmail_footer);
			  $from          = stripslashes($row->adminmail_from);
			  $subject       = $sub;
			}
			
			$to = $email;
			$headers    =  "Content-Type: text/html; charset=iso-8859-1\n";
			$headers   .=  "From: $from\n";

			$body="<table border ='0' cellpadding='0' cellspacing='0' width='90%' >";
			$body.="<tr>";
			$body.="<td width='100%' align='center' valign='top'><br/>";
			$body.="<table border='0' cellpadding='0' cellspacing='0'  width='80%'>";

			$body.="<tr>";
			$body.="<td  width='100%' align='center'> </td>";
			$body.="</tr>";
			$body.="<tr>";
			$body.="<td  width='100%' align='left'> $head</td>";
			$body.="</tr>";

			$body.="<tr>";
			$body.="<td  width='100%' align='left'>&nbsp;</td>";
			$body.="</tr>";
			$body.="<tr>";
			$body.="<td width='100%' align='left'>$message";
			$body.="</td></tr>";
			$body.="<tr>";
			$body.="<td width='100%' align='left'>";
			$body.="</td></tr>";
			$body.="<tr>";
			$body.="<td  width='100%' align='left'>&nbsp;</td>";
			$body.="</tr>";
			$body.="<tr>";
			$body.="<td  width='100%' align='left'>$footer</td>";
			$body.="</tr>";
			$body.="<tr>";
			$body.="<td  width='100%' align='center'></td>";
			$body.="</tr>";

			$body.="</table>";
			$body.="</td>";
			$body.="</tr>";
			$body.="</table>";
			$body=str_replace("[mer_firstname]",$_POST['first_name'],$body);
			 $body=str_replace("[mer_lastname]",$_POST['last_name'],$body);
			 $body=str_replace("[mer_company]",$_POST['av_company'],$body);
			 $body=str_replace("[mer_email]",$_POST['av_email'],$body);
			 $body=str_replace("[mer_loginlink]",'',$body);
			 $body=str_replace("[mer_password]",$pass,$body);
			 
			 $body=str_replace("[from]",'churchcard1@gmail.com',$body);
			 $body=str_replace("[today]",$today,$body);
			 $success = mail($to,$subject,$body,$headers);
			 if (!$success) {
				$errorMessage = error_get_last()['message'];
				}	
			$_SESSION['successr'] = "You have registered successfully. Your password will be sent through email";
			redirect(SITEURL.'signup.php'.$slug);
		
	}else{
		$_SESSION['failurer'] = mysqli_error($con);
		redirect(SITEURL.'signup.php'.$slug);
	}
}
?>
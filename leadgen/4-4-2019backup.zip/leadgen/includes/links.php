<li class="nav-item">
	<a class="nav-link" href="index.php?Act=home" >
		<i class="nc-icon nc-chart-pie-35"></i>
		<p>Dashboard</p>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link"  href="index.php?Act=accounts">
		<i class="nc-icon nc-notes"></i>
		<p>Profile</p>
	</a>
</li>
<li class="nav-item">
	<a class="nav-link" href="index.php?Act=programs&programId=<?=$program?>">
		<i class="nc-icon nc-paper-2"></i>
		<p>Campaigns</p>
	</a>
</li>
<li class="nav-item ">
	<a class="nav-link" href="index.php?Act=daily">
		<i class="nc-icon nc-chart-bar-32"></i>
		<p>Reports</p>
	</a>
</li>
<li class="nav-item ">
	<a class="nav-link" href="index.php?Act=all_transaction">
		<i class="nc-icon nc-money-coins"></i>
		<p>Transaction (0)</p>
	</a>
</li>
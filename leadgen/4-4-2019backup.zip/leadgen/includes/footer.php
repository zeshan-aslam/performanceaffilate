<footer class="footer">
			<div class="container">
				<nav>
					<ul class="footer-menu">
						<li>
							<a href="index.php?Act=home">
								Home
							</a>
						</li>
					</ul>
					<p class="copyright text-center">
						©
						<script>
							document.write(new Date().getFullYear())
						</script>
						<a href="#">AVAZ</a>, Affiliate Network
					</p>
				</nav>
			</div>
		</footer>
	</div>
</div>
<div class="fixed-plugin">
	<div class="dropdown show-dropdown">
		<a href="dashboard.html#" data-toggle="dropdown">
			<i class="fa fa-cog fa-2x"> </i>
		</a>
		<ul class="dropdown-menu">
			<li class="header-title"> Sidebar Style</li>
			<li class="adjustments-line">
				<a href="javascript:void(0)" class="switch-trigger">
					<p>Background Image</p>
					<label class="switch-image">
						<input type="checkbox" data-toggle="switch" checked="" data-on-color="info" data-off-color="info">
						<span class="toggle"></span>
					</label>
					<div class="clearfix"></div>
				</a>
			</li>
			<li class="adjustments-line">
				<a href="javascript:void(0)" class="switch-trigger">
					<p>Sidebar Mini</p>
					<label class="switch-mini">
						<input type="checkbox" data-toggle="switch" data-on-color="info" data-off-color="info">
						<span class="toggle"></span>
					</label>
					<div class="clearfix"></div>
				</a>
			</li>
			<li class="adjustments-line">
				<a href="javascript:void(0)" class="switch-trigger">
					<p>Fixed Navbar</p>
					<label class="switch-nav">
						<input type="checkbox" data-toggle="switch" data-on-color="info" data-off-color="info">
						<span class="toggle"></span>
					</label>
					<div class="clearfix"></div>
				</a>
			</li>
			<li class="adjustments-line">
				<a href="javascript:void(0)" class="switch-trigger background-color">
					<p>Filters</p>
					<div class="pull-right">
						<span class="badge filter badge-black" data-color="black"></span>
						<span class="badge filter badge-azure" data-color="azure"></span>
						<span class="badge filter badge-green" data-color="green"></span>
						<span class="badge filter badge-orange active" data-color="orange"></span>
						<span class="badge filter badge-red" data-color="red"></span>
						<span class="badge filter badge-purple" data-color="purple"></span>
					</div>
					<div class="clearfix"></div>
				</a>
			</li>
			<li class="header-title">Sidebar Images</li>
			<li class="active">
				<a class="img-holder switch-trigger" href="javascript:void(0)">
					<img src="<?php echo LEADURL; ?>public/assets/img/sidebar-1.jpg" alt="" />
				</a>
			</li>
			<li>
				<a class="img-holder switch-trigger" href="javascript:void(0)">
					<img src="<?php echo LEADURL; ?>public/assets/img/sidebar-3.jpg" alt="" />
				</a>
			</li>
			<li>
				<a class="img-holder switch-trigger" href="javascript:void(0)">
					<img src="<?php echo LEADURL; ?>public/assets/img/sidebar-4.jpg" alt="" />
				</a>
			</li>
			<li>
				<a class="img-holder switch-trigger" href="javascript:void(0)">
					<img src="<?php echo LEADURL; ?>public/assets/img/sidebar-5.jpg" alt="" />
				</a>
			</li>
			<li class="header-title" id="sharrreTitle">Thank you for sharing!</li>
			<li class="button-container">
				<a target="_blank" href="https://twitter.com/AvazNetwork" id="twitter" class="btn btn-social btn-twitter btn-round"><i class="fa fa-twitter"></i></a>
				<a target="_blank" href="https://www.facebook.com/Avaz-Affiliate-Network-1637388159698131/" id="facebook" class="btn btn-social btn-facebook btn-round"><i class="fa fa-facebook-square"></i></a>
			</li>
		</ul>
	</div>
</div>
<!--   Core JS Files   -->
<script src="<?php echo LEADURL; ?>public/assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo LEADURL; ?>public/assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="<?php echo LEADURL; ?>public/assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: https://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB2Yno10-YTnLjjn_Vtk0V8cdcY5lC4plU"></script>
<!--  Chartist Plugin  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/bootstrap-notify.js"></script>
<!--  Share Plugin -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/jquery.sharrre.js"></script>
<!--  jVector Map  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/jquery-jvectormap.js" type="text/javascript"></script>
<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/moment.min.js"></script>
<!--  DatetimePicker   -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/bootstrap-datetimepicker.js"></script>
<!--  Sweet Alert  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/sweetalert2.min.js" type="text/javascript"></script>
<!--  Tags Input  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/bootstrap-tagsinput.js" type="text/javascript"></script>
<!--  Sliders  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/nouislider.js" type="text/javascript"></script>
<!--  Bootstrap Select  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/bootstrap-selectpicker.js" type="text/javascript"></script>
<!--  jQueryValidate  -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/jquery.validate.min.js" type="text/javascript"></script>
<!--  Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/jquery.bootstrap-wizard.js"></script>
<!--  Bootstrap Table Plugin -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/bootstrap-table.js"></script>
<!--  DataTable Plugin -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/jquery.dataTables.min.js"></script>
<!--  Full Calendar   -->
<script src="<?php echo LEADURL; ?>public/assets/js/plugins/fullcalendar.min.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="<?php echo LEADURL; ?>public/assets/js/light-bootstrap-dashboard.js" type="text/javascript"></script>
<!-- Light Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo LEADURL; ?>js/demo.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        demo.showNotification();

        demo.initVectorMap();
  });

 function readURL(input) {
		var imgpreview=DisplayImagePreview(input);
		$(".img_preview").show();
		$(".addimg_preview").hide();
		var url= "../controller/accounts.php";
		 ajaxFormSubmit(url,'#Ajaxform',function(output){
			var data=JSON.parse(output);
			if(data.status=='success'){
				$('.im_progress').fadeOut();
				location.reload();
			}else{
				alert("Something went wrong.Please try again.");
				$(".img_preview").hide();
			}
		});   
} 

function DisplayImagePreview(input){
		console.log(input.files);
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$('#img_preview').attr('src', e.target.result);
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	 function ajaxFormSubmit(url, form, callback) {
		var formData = new FormData($(form)[0]);
		formData.append('leadgenid', '<?php echo $leadgenid; ?>');
		formData.append('action', 'uploadimage');
		$.ajax({
			url: url,
			type: 'POST',
			data: formData,
			datatype: 'json',
			beforeSend: function() {
			// do some loading options
			},
			success: function(data) {
			callback(data);
			},
			complete: function() {
			// success alerts
			},
			error: function(xhr, status, error) {
				alert(xhr.responseText);
			},
			cache: false,
			contentType: false,
			processData: false
		});
} 

</script>	
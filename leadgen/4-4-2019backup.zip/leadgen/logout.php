<?php
include('../config.php');
leadgenlogout();
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-4 col-sm-6">
			<div class="card card-stats">
				<div class="card-body ">
					<div class="row">
						<div class="col-5">
							<div class="icon-big text-center icon-warning">
								<i class="nc-icon nc-money-coins text-warning"></i>
							</div>
						</div>
						<div class="col-7">
							<div class="numbers">
								<p class="card-category">Account Balance </p>
								<h4 class="card-title"></h4>
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer ">
					<hr>
					<div class="stats">
						<i class="fa "></i> <a href="index.php?Act=add_money">Add Money To Account</a>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-lg-4 col-sm-6">
			<div class="card card-stats">
				<div class="card-body ">
					<div class="row">
						<div class="col-5">
							<div class="icon-big text-center icon-warning">
								<i class="nc-icon nc-bank text-success"></i>
							</div>
						</div>
						<div class="col-7">
							<div class="numbers">
								<p class="card-category">Today's Spend</p>
								
						
								<h4 class="card-title"></h4>
							</div>
						</div> 
					</div>
				</div>
				<div class="card-footer ">
					<hr>
					<div class="stats">
						<i class="fa "></i> <?php echo date('d/m/Y'); ?>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-lg-4 col-sm-6">
			<div class="card card-stats">
				<div class="card-body ">
					<div class="row">
						<div class="col-5">
							<div class="icon-big text-center icon-warning">
								<i class="nc-icon nc-paper-2 text-primary"></i>
							</div>
						</div>
						<div class="col-7">
							<div class="numbers">
								<p class="card-category">Campaigns</p>
								<h4 class="card-title"></h4>
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer ">
					<hr>
					<div class="stats">
						<i class="fa "></i> <a href="index.php?Act=programs&programId=">View</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4">
			<div class="card ">
				<div class="card-header ">
					<h4 class="card-title">Daily</h4>
					<p class="card-category">Clicks Vs Sales Vs Leads</p>
				</div>
				<div class="card-body ">
					<div id=chartEmail class="ct-chart ct-perfect-fourth"></div>
				</div>
				<div class="card-footer ">
				<div class="legend">
					<i class="fa fa-circle text-info chatclicks"></i> Clicks (0)
					<i class="fa fa-circle text-danger chatleads"></i> Leads (0)
					<i class="fa fa-circle text-warning chatsale"></i> Sales (0)
				</div>
				<hr>
				<div class="stats">
					<i class="fa fa-clock-o"></i> <?php echo date('d/m/Y'); ?>
				</div>
				</div>
			</div>
		</div>
		<div class="col-md-8">
			<div class="card ">
				<div class="card-header ">
					<h4 class="card-title">Monthly</h4>
					<p class="card-category">Clicks Vs Sales Vs Leads</p>
				</div>
				<div class="card-body ">
					<div id=chartHours class="ct-chart"></div>
				</div>
				<div class="card-footer ">
					<div class="legend">
						<i class="fa fa-circle text-info chatclicks"></i> Clicks
						<i class="fa fa-circle text-warning chatleads"></i> Leads
						<i class="fa fa-circle text-danger chatsale"></i> Sales
						
					</div>
					<hr>
					<div class="stats">
						<i class="fa fa-history"></i> <?php echo date('F'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-6">
			<div class="card ">
				<div class="card-header ">
					<h4 class="card-title">Yearly</h4>
					<p class="card-category">Leads Vs Sales</p>
				</div>
				<div class="card-body ">
					<div id="chartActivity" class="ct-chart"></div>
				</div>
				<div class="card-footer ">
					<div class="legend">
						<i class="fa fa-circle text-info chatleads"></i> Leads
						<i class="fa fa-circle text-danger chatsale"></i> Sales
					</div>
					<hr>
					<div class="stats">
						<i class="fa fa-check"></i> Data Last Updated: <?php echo date('Y'); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card  card-tasks">
				<div class="card-header ">
					<?php 
					$lastloginsql = select("user_log","user_id = '$leadgenid'order by date DESC limit 1"); 
					$lastlogrow = mysqli_fetch_array($lastloginsql)
					?>
					<h4 class="card-title">Login History</h4>
					<p class="card-category">Last Login ip: <?php echo $lastlogrow['ip']; ?></p>
				</div>
				<div class="card-body ">
					<div class="table-full-width">
					<?php $loginsql = select("user_log","user_id = '$leadgenid'order by date DESC limit 7"); ?>
						<table class="table">
							<tbody>
							<?php while($logrow = mysqli_fetch_array($loginsql)){ ?>
								<tr>
									<td>
										<div class="form-check">
											<label class="form-check-label">
												<input class="form-check-input" type="checkbox" value="">
												<span class="form-check-sign"></span>
											</label>
										</div>
									</td>
									<td><?php echo $logrow['ip']; ?> - <?php echo date('d/m/Y',strtotime($logrow['date'])); ?> @ <?php echo date('h:i',strtotime($logrow['date'])); ?></td>
									<td class="td-actions text-right">
									</td>
								</tr>
							<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
				<div class="card-footer ">
					<hr>
					<div class="stats">
						<i class="now-ui-icons loader_refresh spin"></i> Last Succesful Login: <?php echo date('d/m/Y',strtotime($lastlogrow['date'])); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('../config.php');
if(!leadgenuser()){
	redirect(SITEURL);
}
$Act	= isset($_GET['Act']) ? $_GET['Act'] : '';
 $welcomeflag = 0; 	
if(isset($_SESSION['successlogin'])){
	$welcomeflag = 1; 
	unset($_SESSION['successlogin']);
}
$leadgenid = leaduserinfo('id');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>AVAZ Affiliate Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
<!-- CSS Files -->
<link href="<?php echo LEADURL; ?>public/assets/css/bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo LEADURL; ?>public/assets/css/light-bootstrap-dashboard.css.css" rel="stylesheet" />
<link href="<?php echo LEADURL; ?>public/assets/css/demo.css" rel="stylesheet" />
<!--<link rel="stylesheet" type="text/css" href="style.css"/>-->
<script>var is_show_welcome = '<?php echo $welcomeflag; ?>'; </script>
</head>
<body>
	<div class="wrapper">
		<!-- Sidebar -->
		<?php	include 'includes/sidebar.php';?>
		 <div class="main-panel">
			<!-- Start Navbar -->
			<?php	include 'includes/header.php';?>
			 <!-- End Navbar -->
			<div class="content">
				<?php include "process.php";?> 
			</div>
			<?php include "includes/footer.php";?>
		 </div>
	</div>
</body>
</html>
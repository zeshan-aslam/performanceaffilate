<?php
include('../../config.php');
if(isset($_POST['submit_post']))
{
	global $prefix,$con;
	$postid = isset($_GET['pid']) ? $_GET['pid'] : -1;
	$slug = '';
	if($postid != -1){ $slug = '?action=edit&id='.$postid; }
		$target = ROOT.'/img/';
		$target = $target . basename( $_POST['company_name'].$_FILES['logo_name']['name']) ;
		$filename = $_POST['company_name'].$_FILES['logo_name']['name'];
		$types = array('image/jpeg', 'image/gif', 'image/png');
		if(!empty($_FILES['logo_name']['name'])){
			if (in_array($_FILES['logo_name']['type'], $types)) {
				move_uploaded_file($_FILES['logo_name']['tmp_name'], $target);
				$_POST['config']['logo_name'] = $filename;
			} else {
				$_SESSION['faliureconfig'] = "Sorry your file was not uploaded. It may be the wrong filetype. We only allow JPG, GIF, and PNG filetypes.";
				
				redirect(ADMINURL.'company-new.php'.$slug);
				exit;
			} 
		}else{
			$_POST['config']['logo_name'] = isset($_POST['logname']) ? $_POST['logname'] : '';
		}
		$_POST['config']['question_info'] = isset($_POST['question']) ? $_POST['question'] : '';
		$inputs['config'] = serialize($_POST['config']);
		$inputs['questions'] = serialize($_POST['dropquestion']);
		$inputs['questionoption'] = serialize($_POST['dropopt']);
		

		$page = $_POST['page'];
		
		if($postid == -1){
			$datacom = array(
			'company_name' => mysqli_real_escape_string($con,$_POST['company_name']),
			'company_slug' => create_slug(mysqli_real_escape_string($con,$_POST['company_name']))
			);
			$lastid = insert('company', $datacom);
				if($lastid){
					$dataconfig = array(
					'config_name' => 'company_data',
					'config_value' => base64_encode(serialize($inputs)),
					'user_id' => $lastid,
					);
					$success = insert('config', $dataconfig);
				}
				
				if($success){
					foreach($page as $key => $val){
						$vals = mysqli_real_escape_string($con,$val);
						 $success = mysqli_query($con,"INSERT INTO ".$prefix."posts (post_description,post_slug,user_id) VALUES ('$vals','$key','$lastid')");
					}
				}
				
		}else{
			$success = mysqli_query($con,"update ".$prefix."config set config_value = '".base64_encode(serialize($inputs))."' where user_id = '$postid' ");
			if($success){
					foreach($page as $key => $val){
						$vals = mysqli_real_escape_string($con,$val);
						 $successs = mysqli_query($con,"update ".$prefix."posts set post_description = '$vals' where user_id = '$postid' and post_slug = '$key'");
					}
			}
		}
		

		if($success){
			$_SESSION['successconfig'] = "Record Saved successfully";
			redirect(ADMINURL.'company-new.php'.$slug);
		}else{
			$_SESSION['faliureconfig'] = "Please try again";
			redirect(ADMINURL.'company-new.php'.$slug);
		}
}

if(isset($_POST['is_submit']))
{
	$userid = $_POST['userid'];
	$data = array(
		'is_confirmed' => $_POST['is_confirmed'],
		'is_sold' => $_POST['is_sold'],
		'is_closed' => $_POST['is_closed'],
	);
	$da = array(
		'user_id' => $userid,
		'user_key' => 'sold_to',
		'user_meta' => $_POST['sold_to'],
	);
	insert('joinavazmeta',$da);

	foreach($data as $key => $val){
		 $success = update_joinavaz_meta($userid,$key,$val);
	}
	if($success){
			$_SESSION['successconfig'] = "Record Saved successfully";
			redirect(ADMINURL.'view.php?action=view&id='.$userid);
		}else{
			$_SESSION['faliureconfig'] = "Please try again";
			redirect(ADMINURL.'view.php?action=view&id='.$userid);
		}
}

if(isset($_POST['action']) && $_POST['action'] == 'delete'){
	global $prefix,$con;
	 $tableid= $_POST['tableid'];
	$tablecom = $prefix.'company';
	$tablecon = $prefix.'config';
	$tablepos = $prefix.'posts';
	$result = mysqli_query($con,"delete from $tablecom where id='$tableid'");
	if($result){
		$companydata = unserialize(base64_decode(get_config_meta('company_data', $tableid, true)));
		$logoname = $companydata['logo_name'];
		$target = ROOT.'/img/';
		unlink($target.$logoname);
		$result = mysqli_query($con,"delete from $tablepos where user_id='$tableid'");
		$result = mysqli_query($con,"delete from $tablecon where user_id='$tableid'");
		
	}
	if($result){
	$_SESSION['success'] = "Record Successfully Deleted"; 
	}else{
		echo mysqli_error($con);
	}
}

if(isset($_POST['action']) && $_POST['action'] == 'checkcompany'){
	global $prefix,$con;
	 $comname= $_POST['comname'];
	$tablecom = $prefix.'company';
	$result = mysqli_query($con,"select * from $tablecom where company_name = '$comname'");
	$is_exist = mysqli_num_rows($result);
	if($is_exist > 0){
		echo json_encode(array('exist' => true));
	}else{
		echo json_encode(array('exist' => false));
	}
	die;
}
?>
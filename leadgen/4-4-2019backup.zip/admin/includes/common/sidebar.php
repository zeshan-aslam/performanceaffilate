<div class="am-sideleft">
      <div class="tab-content">
        <div id="mainMenu" class="tab-pane active">
          <ul class="nav am-sideleft-menu">
            <li class="nav-item">
              <a href="index.php" class="nav-link active">
                <i class="icon ion-ios-home-outline"></i>
                <span>Dashboard</span>
              </a>
            </li><!-- nav-item -->
           <!-- <li class="nav-item">
              <a href="" class="nav-link with-sub active show-sub">
                <i class="icon ion-ios-gear-outline"></i>
                <span>Question</span>
              </a>
              <ul class="nav-sub">
                <li class="nav-item"><a href="question.php" class="nav-link">All Question</a></li>
                <li class="nav-item"><a href="question-new.php" class="nav-link">Add Question</a></li>
              </ul>
            </li>
			<li class="nav-item">
              <a href="" class="nav-link with-sub active show-sub">
                <i class="icon ion-ios-gear-outline"></i>
                <span>Pages</span>
              </a>
              <ul class="nav-sub">
                <li class="nav-item"><a href="post.php" class="nav-link">All Pages</a></li>
                <li class="nav-item"><a href="post-new.php" class="nav-link">Add Page</a></li>
              </ul>
            </li>-->
			
			<li class="nav-item">
              <a href="company-new.php" class="nav-link active">
                <i class="icon ion-ios-home-outline"></i>
                <span>Add Company</span>
              </a>
            </li><!-- nav-item -->
          </ul>
        </div><!-- #mainMenu -->
        
      </div><!-- tab-content -->
    </div><!-- am-sideleft -->
	<div class="am-mainpanel">
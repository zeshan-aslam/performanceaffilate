<?php include('includes/common/header.php'); ?>
<?php include('includes/common/sidebar.php'); ?>
	<div class="am-pagetitle">
        <h5 class="am-title">Dashboard</h5>
        
      </div><!-- am-pagetitle -->

      <div class="am-pagebody">
		<div class="card pd-20 pd-sm-40">
			 <div class="table-wrapper">
				<?php $sql = select("company order by id DESC"); ?>
				<table id="datatable1" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">Company</th>
                 <th>Submission List</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody> 
				<?php while($row = fetch($sql)){ 
				
				?>
				<tr>
					<td><?php echo $row['company_name']; ?></td>
					<td><a href="view-list.php?cid=<?php echo $row['id']; ?>">View</a></td>
					<td><a href="company-new.php?action=edit&id=<?php echo $row['id']; ?>">Edit</a> | <a  href="javascript:;" onClick="deletetablerow(<?php echo $row['id']; ?>,'Are you sure you like to delete  <?php echo $row['company_name']; ?>')">Delete</a> | <a  target="_blank" href="<?php echo SITEURL.$row['company_slug']; ?>" >View</a></td>
				</tr>
				<?php } ?>
              </tbody>
            </table>
			 </div>
			 
		</div>
	</div><!-- am-pagebody -->
      
<?php include('includes/common/footer.php'); ?>
<?php
include('../config.php');
logout();
?>
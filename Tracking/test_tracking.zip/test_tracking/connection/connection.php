<?php
$server ="localhost";
$user ="root";
$password ="";
$db ="tracking_db";

$conn=mysqli_connect($server,$user,$password,$db);

?>
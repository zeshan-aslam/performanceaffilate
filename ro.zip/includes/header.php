<?php
    include_once 'includes/db-connect.php';
    include_once 'includes/session.php';
    header("Cache-control: private"); 
    include_once 'includes/constants.php';
    include_once 'includes/functions.php';
    include_once 'includes/allstripslashes.php';

    $msg = $_REQUEST['msg'];
    $partners   = new partners;
    
    $Act = isset($_GET['Act']) ? $_GET['Act'] : "";
    if(!empty($_POST['languageid'])) $_SESSION['LANGUAGE'] = intval($_POST['languageid']);

    # For language
    $language   = $_SESSION['LANGUAGE'];
    if (empty($language)) 
        $lang   = "english";
    else{
        # Get langauge
        $sqllang    = " SELECT * FROM partners_languages WHERE languages_id = '$language'"; 
        $reslang    = mysqli_query($con,$sqllang);
        if($rowlang = mysqli_fetch_object($reslang)) 
            $lang   = strtolower(trim(stripslashes($rowlang->languages_name)));
        
        # langauge file name
        $filename   = "lang/".$lang.".php";
        
        # check whether file exists
        if(!file_exists($filename)){
            $lang   = "english";
            $language = "";
        }
    }
    require ("lang/".$lang.".php");

    # Getting Default currency Details
    $currency_code  = $default_currency_code;
    $cur_sql        = " SELECT * FROM partners_currency WHERE currency_code = '$currency_code' ";
    $res_cur        = mysqli_query($con, $cur_sql);

    if(mysqli_num_rows($res_cur) > 0){
        $row_cur = mysqli_fetch_object($res_cur);
        $currSymbol = stripslashes($row_cur->currency_symbol);
        $_SESSION['DEFAULTCURRENCYSYMBOL'] = $currSymbol;
        $currValue  = stripslashes($row_cur->currency_caption);
        $currCode   = stripslashes($row_cur->currency_code);
    }
    
    # daily procedures

    include_once 'dailyroutine.php';
    ChangeStaus($minimum_amount);
    getProgramFee();
    setPending();
    payMembership();
    setMemPending();
 
    # Remove this when cron job is set for this file
    # include_once "cron/dailyjobs_anp.php";
?>

<!doctype html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
    

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/imgs/favicon.png">

    <title>AVAZ Affiliate Network</title>

    <!-- Bootstrap core CSS  & Other Thirdparty-->
    <link href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="//stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.css" />

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>
	 <!-- <header> -->
    <div class="top-bar">
        <div class="container">
            <p class="help-text"> Have A Question? <b><span>+44 (0)20 3287 2232</span></b></p>
			<div class="right_column">
			  <p class="loginlead"><a href="https://avaz.co.uk/leadgen">Login To Avaz Leadgen</a></p>
            <ul class="social-links">
              <!--  <li><a href="https://www.linkedin.com/company/#" target="_blank" title="Avaz LinkedIn " alt="Avaz LinkedIn "><i class="fa fa-linkedin"></i></a></li>-->
                <li><a href="https://twitter.com/AvazNetwork" target="_blank" title="Avaz Twitter" alt="Avaz Twitter"><i class="fa fa-twitter"></i></a></li>
                <li><a href="https://www.facebook.com/Avaz-Affiliate-Network-1637388159698131/" target="_blank" title="Avaz Facebook" alt="Avaz Facebook"><i class="fa fa-facebook"></i></a></li>
            </ul>
			</div>
        </div>
        <!--container-->
    </div>
    <nav id="mainNav" class="navbar navbar-expand-md navbar-light sticky-top shadow-sm extra-fat">
        <div class="container">
            <a class="navbar-brand" href="/">
                <img src="assets/imgs/logo.png">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#about-us">About us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#sec-merchants">Merchants</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#sec-affiliates">Affiliates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0);" data-toggle="modal" data-target="#popGDPR">GDPR</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#contact-us">Contact us</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-4 mobile-nav-fix">
                    <li class="nav-item nav-button rounded mr-2">
                        <a class="nav-link rounded nav-login-trigger" data-toggle="modal" href="javascript:void(0)" onclick="openLoginModal();">Sign In</a>
                    </li>
                    <li class="nav-item nav-button nav-button-block rounded">
                        <a class="nav-link rounded js-scroll-trigger" href="#join-now">Sign Up</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- </header> -->

    <main id="home" role="main">
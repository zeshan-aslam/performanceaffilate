<?
//---------------menu----------------------------------------------------//
    $common_id				= "ID";

    $menu_home					="Home";
	 $lang_Dashboard			="Dashboard";
    $menu_accounts				="Accounts";
    $menu_programs				="Programs";
    $menu_rotator				="Rotator";
    $menu_getlinks				="GetLinks";
    $menu_reports				="Reports";
    $Payment_his				="Payment History";
    $menu_quit					="Quit";
    $lang_SubsaleHistory2       = "Subsale History";
    $lang_affiliate_imp         = "Impression";
    $lang_pay_list_view			= "View";
    $lang_pay_list_pgm			= "PGM";
	
	$lang_AccountBalance		="Account Balance";
	 $lhome_TodaySpend			="Today's Earnings";
	 $lhome_LiveAffiliates		="Live Programs";
	 $lang_Payment				="Payment";
	$lang_PaymentHistory		="Payment History";
//-----------------------------------------------------------------------//

//--------------------------------------Affiliate_help page,myAffiliateprograms.php----------//
	$lang_aff_approved_help		="Affiliate is approved to take advertising links";
	$lang_aff_waiting_help		="Affiliate is waiting for approval to get advertising links";
	$lang_aff_blocked_help		="Affiliate is blocked ";
	$lang_aff_help				="Help";
//--------------------------------------------------------------------------------------------//

//-----------------------------Affiliate_help page,myAffiliateprograms.php,bycategory.php------//
    $lang_aff_approved			="Approved";
	$lang_aff_waiting			="Waiting";
	$lang_aff_blocked			="Blocked";
	$lang_aff_total				="Total Programs";

//---------------------------------------------------------------------------------------------//


//----------------------------Affiliate_help page,bycategory.php--------------------------------//
    $lang_aff_notjoined			="Not joined";
//----------------------------------------------------------------------------------------------//

//----------------------------Affiliate_help page------------------------------------------------//
	$lang_aff_notjoined_help	="Affiliate has not joined for this program";
//-----------------------------------------------------------------------------------------------//

//-------------------------------bycategory.php--------------------------------------------------//
	$lang_bycategory_all			="All Category";
	$lang_bycategory_new			="Newest Programs";
	$lang_bycategory_search			="Search Programs";
	$lang_bycategory_go				="Go";
//-----------------------------------------------------------------------------------------------//




//-----------------bycategory.php,Affiliateprograms_links.php------------------------------------//
 $lang_affiliate_pgms_category	="Category";
 //----------------------------------------------------------------------------------------------//

 //-----------------Affiliateprograms_links.php,myAffiliateprograms.php--------------------------//
 $lang_affiliate_pgms_my		="My Affiliate Programs";

 //----------------------------------------------------------------------------------------------//

 //----------------Affiliateprograms_links.php----//
 $lang_affiliate_pgms_all		="All Affiliate Programs";
 //----------------------------------------------------------------------------------------------//

 //--------------------------Affiliate_programs,home.php,report_daily,forperiod------------------//
   $lang_affiliate_head_click	 ="Click";
   $lang_affiliate_head_sale	 ="Sale";
   $lang_affiliate_head_lead	 ="Lead";
   $lang_affiliate_head_subsale ="SubSale";
  //-----------------------------------------------------------------------------------------------//


  //-------------------------------------Affiliate_programs--------------------------------------//
   $lang_affiliate_head_url	     ="Program Url";
   $lang_affiliate_head_merchant ="Merchant";
   $lang_affiliate_head_action	 ="Action";
   $lang_affiliate_head_status   ="Status";
   $lang_affiliate_head_check	 ="Check All";
   $lang_affiliate_head_uncheck  ="Uncheck All";
   $lang_affiliate_head_join	 ="Join Selected";
   $lang_affiliate_head_suspend	 ="Suspend Selected";
   $lang_affiliate_joinpgm		 ="JoinPgm";
   $lang_affiliate_getlinks		 ="GetLinks";
   $lang_affiliate_blocked		 ="Blocked";
   $lang_affiliate_waiting		 ="Waiting";
   $lang_affiliate_suspend_msg	 ="Are you sure you want to suspend selected programs?";
   $lang_affiliate_join_msg		 ="Are you sure you want to join for selected programs?";
   $lang_affiliate_rejoin		 ="ReJoin";
//--------------------------------------------------------------------------------------//

//-------------------------------home.php-----------------------------------------//
	$lang_home_pgmstat              ="Program Statistics";
	$lang_home_maximum_limit_reached= "Your account balance has reached the maximum balance amount limit.";
	$lang_home_ad_links             ="Advertising Links";
	$lang_home_html                 ="Html";
	$lang_home_text                 ="Text";
	$lang_home_banner               ="Banner";
	$lang_home_popup                ="Popup";
	$lang_home_flash                ="Flash";
	$lang_home_no_link              ="No Links Added to This Program";
	$lang_home_statistics           ="Statistics";
	$lang_home_total_subsale        ="Total Sub Sale";
	$lang_home_report               ="Report";
	$lang_home_search               ="Search";
	$lang_home_select               ="Select Report";
	$lang_pend_subsale              ="Pending Subsale";
	$lang_home_manage_subid			="Manage Sub-ID List";
//---------------------------------------------------------------------------------------------------//

//-------------------------------home.php,report_links------------------------------------------------//
	$lang_home_daily                ="Daily";
	$lang_home_forperiod            ="For Period";
	$lang_home_links                ="Links";
//---------------------------------------------------------------------------------------------------//

//-------------------------------home.php,forperiod,rotator-------------------------------------------------//
	$lang_home_paid                 ="Paid";
	$lang_home_pending              ="Pending";
	$lang_home_reversed             ="Reversed";
	$lang_home_approved             ="Approved";
	$lang_home_waiting              ="Waiting";
//---------------------------------------------------------------------------------------------------//



//-------------------------------home.php,reverse_sales.php,report_daily,forperiod--------------------//
	$lang_home_all_pgms             ="All Programs";
	$lang_home_number               ="Number";
	$lang_home_commission           ="Commission";
//---------------------------------------------------------------------------------------------------//


//-------------------------------home.php,reverse_sales.php,report_daily,forperiod--------------------//
	$lang_home_transaction          ="Transaction";
	$lang_home_pgms                 ="Programs";
	$lang_home_reversesale          ="Reverse Sales";
//---------------------------------------------------------------------------------------------------//

//-------------------------------reverse_sales.php--------------------------------------------------//
	$lang_reverse_details           ="Affiliate Details";
	$lang_reverse_sale              ="Sale";
	$lang_reverse_name              ="Name";
	$lang_reverse_company           ="Company";
	$lang_reverse_url               ="Site Url";
	$lang_reverse_commission        ="Commission";
	$lang_reverse_date              ="Date";
	$lang_reverse_status            ="Status";
	$lang_reverse_commission        ="Commission";
//---------------------------------------------------------------------------------------------------//

//--------------------------------------report_daily-------------------------------------------------//
	$lang_report                    ="Statistics on";
	$lang_calender                  ="Calendar";
//-----------------------------------------------------------------------------------------------------//

//--------------------------------------forperiod-------------------------------------------------//
	$lang_report_stat               ="Statistics For Custom Period";
	$lang_report_forperiod          ="For Period";
	$lang_report_from               ="From";
	$lang_report_to                 ="To";
	$lang_report_view               ="View";
	$lang_report_err                ="Please Enter Valid Date" ;
	$lang_report_SearchProgram      ="Search Programs";
	$lang_report_AllProgram         ="All Program";
//-----------------------------------------------------------------------------------------------------//


//--------------------------------------transaction-------------------------------------------------//
	$lang_trans_commission          ="Commission";
	$lang_trans_date                ="Date";
	$lang_trans_status              ="Status";
	$lang_trans_type                ="Type";
	$lang_trans_merchant            ="Merchant";
	$lang_trans_empty_msg           ="Please select Sale,Click,Lead or all ";
	$lang_trans_completereport      ="Complete Report";

//-----------------------------------------------------------------------------------------------------//

//-----------------------------subidreport-------------------------------------------------------------//
	$lang_subid_title				= "Sub-ID Report";
	$lang_subid_forperiod			= "For Period";
	$lang_subid_from				= "From";
	$lang_subid_to					= "To";
	$lang_subid_searchsubid			= "Search Sub-ID";
	$lang_subid_allsubid			= "All Sub-ID";
	$lang_subid_report				= "Sub-ID Report";
	$lang_subid_till				= "Till";

//-----------------------------------------------------------------------------------------------------//

//-------------------------------Affiliate account----------------------------------------------------//
	$lang_AffiliateLoginInfo            =   "Affiliate Login Info";
	$lang_EmailId                       =   "Email Id";
	$lang_Password                      =   "Password";
	$lang_AffiliateContactInfo          =   "Affiliate Contact Info";
	$lang_FirstName                     =   "First Name";
	$lang_LastName                      =   "Last Name";
	$lang_Company                       =   "Company";
	$lang_URL                           =   "URL";
	$lang_Address                       =   "Address ";
	$lang_Category                      =   "Category";
	$lang_Phone                         =   "Phone";
	$lang_Fax                           =   "Fax";
	$lang_Type                          =   "Type";
	$lang_City                          =   "City";
	$lang_Country                       =   "Country";
	$lang_Edit                          =   "Edit";
	$lang_SelectaCountry                =   "Select a Country";
	$selectacategory                    =   "select a category";
	$lang_success_message               =   "Affiliates Contact Info Updated successfully!!..";
	$lang_invalid                       =   "Invalid Entry...Please do not empty any Required fields ";
	$lang_Category                      =   "Category";
	$lang_ParentId                      =   "ParentId";
	$lang_PaymentInformation            =   "Payment Information";
	$lang_Modofpay                      =   "ModeofPay";
	$lang_BankName                      =   "Bank Name";
	$lang_Minimumcheck                  =   "Minimum check";
	$lang_Payableto                     =   "Payable to";
	$lang_BankAccount                   =   "Bank Account";
	$lang_BankEmail                     =   "Bank Email";
	$lang_Bankno                        =   "Bank No";
//-----------------------------------------------------------------------------------------------------//


//-----------------------affil_accounts_validate.php----------------------------------------------------//
	$lang_account_success               =   "Affiliates Contact Info Updated  successfully!!.."          ;
	$lang_account_blank                 =   "Invalid Entry...Please do not leave any required fields blank";
//-----------------------------------------------------------------------------------------------------//


//-----------------------login_edit.php---------------------------------------------------------------//
	$lang_ConfirmPassword               =   "Confirm Password";
	$lang_NewPassword                   =   "New Password";
	$lang_OldPassword                   =   "Old Password";
	$lang_EmailId                       =   "Email Id";
	$lang_LoginInfoEdit                 =   "Login Info Edit";
	$lang_close                         =   "Close";
	$pass_mismatch                      =   "New password and Confirm Password Should be Same !! ";
	$lang_pass_success                  =   "Edited Successfully";
//-----------------------------------------------------------------------------------------------------//

//---------------------------------viewprofile_merchant.php--------------------------------------------//

	$lang_MerchantsProfile              =   "Merchants Profile";
	$lang_URL                           =   "URL";
	$lang_Company                       =   "Company";
	$lang_Registered                    =   "Registered";
	$lang_Category                      =   "Category";
	$lang_ProgramDescription            =   "Program Description";
	$lang_YourStatus                    =   "Your Status";
	$lang_ProgramDetails                =   "Program Details";
	$lang_links                         =   "links for this program, that you can put on your sites. All clicks,commissions on this ads are tracked by";
	$lang_thus                          =   "Thus you earn money from your site by redirecting your visitors to ";
	$lang_fromMerchantSite              =   "from Merchant Site";
	$lang_your                          =   "Your Status must be ";
	$lang_togetlinks                    =   "to GetLinks from";
	$lang_hascreated                    =   "has created";
//----------------------------------------------------------------------------------------------------//

//---------------------------rotator.php--------------------------------------------------------------//
     $lang_notjoined_help            ="Affiliate has not joined in this category";
     $lang_CategoryStatus            ="Category Status";
     $lang_Help                      ="Help";
     $lang_view                      ="View All Rotator Categories";
     $lang_Action                    ="Action";
     $lang_Status                    ="Status";
     $lang_rotator                   ="ROTATOR CATEGORIES";
     $lang_norec                     ="No Records on this category... ";
     $lang_no_rec                    ="No Records Found... ";
     $lang_nomerchant                ="No Merchant under this category";
     $lang_catfound                  ="Category Found";
     $lang_total                     ="Total";
     $lang_unjoin_selected           ="Unjoin Selected Programs";
     $lang_join_selected             ="Join Selected Programs";
//----------------------------------------------------------------------------------------------------//

//------------------------link_report3.php----------------------------------------------------------------------//
	$lang_Click                         ="Click Here To Get Html Link";
	$lang_Click_text                    ="Click Here To Get Text Link";
	$lang_Click_pop                     ="Click Here To Get Popup Link";
	$lang_totalrec                      ="Total Records Found";
	$lang_next                          ="Next";
	$lang_previous                      ="Previous";
//----------------------------------------------------------------------------------------------------//
 	 $lang_text_help                    = "Get your text ads from here. The advertising link will be a text and
	                                        description under the link.";
	 $lang_banner_help                  = "Get your banner ads from here.
	                                        The supported formats are .gif , .jpg, .png .";
	 $lang_flash_help                   = "Get your Flash ads from here.
	                                        Copy the text and paste it on your site.";
	 $lang_popup_help                   = "If you want your ads to open in new window,
	                                        Get your ads as pop-up or pop-under";
	 $lang_html_help                    = "Get your HTML ads here. Advertising link is HTML code(html lines or web page)";



	$lang_Gettext                      = "Get texts from&nbsp; Joined Programs";
	$lang_Gettext_help                 =  "Copy and paste the following HTML code to your own web site pages to display this advertising link. Please contact us if you require any assistance.";
	$lang_text_norec                   =  "No Text Ads are added to This Program....   ";

	$lang_Getbanner                    = "Get banners from&nbsp; Joined Programs";
	$lang_banner_norec                 =  "No Banner Ads are added to This Program.... ";

	$lang_Getflash                     = "Get Flash from&nbsp; Joined Programs";
	$lang_flash_norec                  =  "No Flash Ads are added to This Program....  ";

	$lang_Gethtml                      = "Get Html from&nbsp; Joined Programs";
	$lang_html_norec                   =  "No Html Ads are added to This Program....   ";

	$lang_Getpopup                     = "Get Popup from&nbsp; Joined Programs";
	$lang_popup_norec                  =  "No Popup Ads are added to This Program....  ";


	$affiliate_name                     = "Affiliate";
	$affiliate_amount                   = "Amount";
	$affiliate_history                  = "Payment History";
	$affiliate_date                     = "Date Of Payment";
	$affiliate_transaction              = "Transaction";
	$affiliate_merchant                 = "Merchant";
	$affiliate_second                   = "Second Tire Commission";

	$lang_payapalemail                  ="Email";
	$lang_stormemail                    ="Email";
	$lang_payeename                     = "Payee Name";
	$lang_acno                          = "Account No";
	$lang_productid                     ="Product Id";
	$lang_checkoutid                    = "Checkout Id";
	$lang_version                       = "Version";
	$lang_delimdata                     = "DelimData";
	$lang_relayresponse                 = "RelayResponse";
	$lang_login                         = "Login";
	$lang_trankey                       = "Trankey";
	$lang_cctype                        = "cctype";
	$lang_Paypal                        = "PAYPAL";
	$lang_Stormpay                      = "STORMPAY";
	$lang_2Checkout                     = "2CHECKOUT";
	$lang_eGold                         = "EGOLD";
	$lang_Authorize                     = "AUTHORIZE.NET";
	$lang_chkerr                        = "Please Enter 2Checkout Details";
	$lang_autherr                       = "Please Enter Authorize.net Details";
	$lang_egolderr                      = "Please Enter EGold Details";
	$lang_stormerr                      = "Please Enter Valid Storm Pay Email Id";
	$lang_payerr                        = "Please Enter Valid Paypal Email Id";
    $lang_EmailIdAlreadyExist			= "Email Id Already Exist";
	$lang_PaymentGateway                = "Mode of Payment";
	$no_aff_pay                         = "No Payments Are there through Transactions";
	$no_admin_pay                       = "No Payments Are there through Subsale";
	$affiliate_request                  = "Request Payment";
	$request_success                    = "Your request has been sent!!";
	$request_request                    = "Please click here to send Payment Request.";
	$lang_manual_payments               = "Manual Payments";
	$lang_paymentlist                   = "Payments";
	$affiliate_withdraw                 = "Withdraw";
	$affiliate_payment                  = "Payment";
	$affiliate_all                      = "All";
	$affiliate_nopay                    = "Sorry No Manual Payments Found";
	$affiliate_ucant                    = "Sorry Your Account doesn't have enough money to withdraw.";

    $lang_report_Click_pop              = "Please click here to view popup";
    $lang_report_Click					= "Please click here to view html";
    $lang_report_Click_text             =  "Please click here to view text";

    $lang_PaymentHistory2				=" Transaction History";
	$lang_PaymentHistory1				=" Payment History";
	$lang_top_Banner					=" Banner";
	$lang_top_get						=" Get your banner ads from here. The supported formats are .gif , .jpg, .png ";
	$lang_top_select					=" Select banners you need to create banner rotator. Then click on Generate Links and copy code to your site. Generated codes may not work if you disabled cookie on your browser.";

	$lang_top_GetBannersForBannerAdds	=" Get Banners For Banner Adds ";
	$lang_top_SelectForBannerRotator	=" Select For Banner Rotator";
	$lang_top_BannerStatistics			=" Banner Statistics";
	$lang_top_MerchantURL				=" Merchant URL ";
	$lang_top_Click						=" Click";
	$lang_top_Lead						=" Lead";
	$lang_top_Sale						=" Sale";
	$lang_top_BannerCode 				=" Banner Code ";
	$lang_top_Width						=" Width";
	$lang_top_Height					=" Height";
	$lang_top_Selectall					=" Select all the Banners and copy the code form here and paste it on your site. Please Enter value in width and Height Field. Eg : width=480 height=60. ";
    $lang_Account_Details				=" Account Details ( Related To Transaction ) ";
    $lang_Account_sub					=" Account Details ( Related To SubSale ) ";
	$lang_Account_withdraw				=" Account Details ( Withdrawn / Deposited )";
	$lang_state							= "State";
	$lang_zip							= "Zip Code";
	$lang_timezone						= "TimeZone";

    $lang_neteller_caption		    	= "NETeller";
	$lang_neteller_email                = "Email";
	$lang_neteller_accnt                = "Account Number";

	$lang_check_caption                 = "Check By Mail";
	$lang_check_payee                   = "Payee Name";
	$lang_check_curr                    = "Currency";
	$lang_checkerr                      = "Please Enter All Details";

	$lang_wire_caption                  = "Wire Transfer";
	$lang_wire_AccountName              = "Account Name";
	$lang_wire_AccountNumber            = "Account Number";
	$lang_wire_BankName                 = "Bank Name";
	$lang_wire_BankAddress              = "Bank Address ";
	$lang_wire_BankCity                 = "Bank City ";
	$lang_wire_BankState                = "Bank State/Province";
	$lang_wire_BankZip                  = "Bank Postcode/Zip";
	$lang_wire_BankCountry              = "Bank Country";
	$lang_wire_BankAddressNumber        = "Bank Address Number";
	$lang_wire_Nominate                 = "Nominate preferred currency";
	$allreqd                            = "All Fields Are Required";
	$lang_netellererr                   = "Please Enter a valid email address";
    $lang_notjoined						= "You are Not Joined with any of our Merchants !!..";
    $lang_notjoined2                    = "Click Here to join";

    $lang_product_Type               = "Type";
	$lang_product_Product            = "Product";
	$lang_product_Affiliate          = "Affiliate";
	$lang_product_Commission         = "Commission";
	$lang_product_Date               = "Date";
	$lang_product_Status             = "Status";
	$lang_report_no_rec             ="No records Found";
	$lang_report_head               = "Existing Transaction(s)";
    $lang_pdt_report				= "Product";
	$lang_subid_report				= "Sub-ID Report";
    $lang_pdt_files					= "Product Files";
    $lang_pdt_head					= "Product File(s) Management";
    $lang_pdt_norec					= "Sorry! No Product File(s) Found";
    $lang_pdt_download				= "DOWNLOAD";
    $lang_taxId						= "Tax Id";

	//-----Sub Id Management----------
	$lang_subid_title				= "Manage Sub-ID";
	$lang_subid_subid				= "Sub-ID";
	$lang_subid_max					= "(Max. 50 characters)";
	$lang_subid_submit				= "Submit";
	$lang_subid_list				= "Sub-ID List";
	$lang_subid_edit				= "Edit";
	$lang_subid_delete				= "Delete";
	$lang_subid_no_msg				= "You haven't created any Sub-ID so far.";
	$lang_subid_null_msg			= "Please enter a Sub-ID";
	$lang_subid_dupl_msg			= "Same Sub-ID already exists. Please try with another one.";
	$lang_subid_success_msg			= "Successfully updated the Sub-ID";
	$lang_subid_del_msg				= "Successfully deleted the Sub-ID";
	$lang_subid_max_msg				= "Sub-ID can have maximum 50 characters";
	$lang_subid_rawclicks			= "Raw Clicks";
	$lang_subid_rawimpressions		= "Raw Impressions";
	$lang_subid_noreport_msg		= "Sorry...No Transaction was found with Sub-ID.";

	$lang_getlinks_choose_subid		= "Choose A Sub-ID";

    $rotators_join			= "Join selected programs";
    $rotators_unjoin		= "Un join selected programs";
    $cmaff_none				= "--None--";
    $toplinks_text			= "Get<span lang='bg'> your </span>&nbsp;banner&nbsp; ads from here. The supported formats are .gif, .jpg, .png . ";
    $toplinks_banner		= "Banner";
    $toplinks_text2			= "Select &nbsp;banners you needed to create banner rotator &nbsp;. Then click on Generate Links and copy &nbsp;code to your site. Generate code may not work if you disabled cookie on your browser.";

    $getflash_get			= "Get flashs For flash Adds";
    $getflash_select		= "Select For Flash Rotator";
    $getflash_stat			= "Flash Statistics";
    $getflash_url			= "Merchant URL";
    $getflash_code			= "Flash Code";
    $getflash_height		= "Height";
    $getflash_width			= "Width";
    $getflash_text			= "Select all the flashs <br/>and copy the code form here<br>
                 				and paste it on your Site. Please Enter values in width and height fields.";
    $getflash_nomsg			= "Sorry No flashs Found In This Category ...";
    $getflash_switch		= "Select Another Category";

    $getbann_nomsg			= "Sorry No Banners Found In This Category ...";
    $getbann_switch			= "Select Another Category";

    $req1_awr				= "Amount Withdraw Request ";
    $req1_aba				= "Account Balance Amount ";
    $req1_mwa				= "Minimum Withdrawal Amount";
    $req1_rwa				= "Request Withdrawal Amount";
    $req1_but				= "Send Request";

    $genban_your			= "Your Banner Will Look Like This";
    $genban_brcode			= "Banner Rotator Code";
    $genban_copy			= "Copy This Code And Paste it On Your Site";
    $genban_select			= "Select All Text";
    $genban_click			= "Right click and copy..";

    $logine_edit			= " Login Edit";

    $productrep				= "Existing Transaction(s)";

    $genflsh_code			= "Flash Rotator Code";

    $common_back			= "BACK";
    $common_edit			= "Edit";


/*****************************************************************************************************/
//ANP PHASE 4 Additions Start Here
/*****************************************************************************************************/

	//added on 15-June-2006 
        $text_banner_size                        = "Enter the Size for Text Banner";
        $js_numeric_value                        = "Enter a numeric value";
        $text_changesize                        = "Change Size";
        $custom_Border_Color        =  "Border Color";
        $custom_back_Color        =  "Ad BackGround Color";
        $custom_title_Color        =  "Ad Title Color";
        $custom_desc_Color        =  "Ad Description Color";
        $custom_url_Color        =  "Ad URL Color";
        $custom_BorderFont_Color        =  "Border Font Color";
        $custom_apply_color        = "Get Code";
        $custom_color_help        = "After selecting the colors click 'GetCode' and then copy and paste the code to your site";
        $newwindow_text                                = "Open in New Window";

   		$lang_affiliate_head_impr        ="Impression";

// Added for Print Reports Section
		$lang_print_report_head		= "Print Report";
		$lang_export_csv_head		= "Export as CSV";

///////Added on 21-Sept-2006 for the Affiliate Referer Link
	$lang_affiliateSignUpLink   = "Affiliate Referrer Link";
	$lang_affiliateSignUpHelp	= "Copy the following URL and provide it to earn commission by Referring New Affiliates";
	
//Added on 19-October-2006
//New Text AD
	$lang_home_texttemplate						= "Template Text";
	$lang_report_Click_texttemplate             = "Please click here to view Template Text Ad";
	$laddban_TemplateAdtext		= "Get your Text Ads from a Template here.  The advertising link will be a Text and/or an image.";
	
	
	$lang_TrackURL    	=   "Track URL";
	
	$lang_referral_report    	=   "Referral Commission";
	$lang_referral_downlines   	=   "Downlines";
	$lang_referral_salesMade   	=   "Sales Made";
	$lang_total_commission    	=   "Total Commission";

# Multiple COmmission Structure
	$lang_commission_structure	= "Commission Structure ";
	$lang_value_above			= "Above";
	$lang_viewCommision 		= "View Commission";
?>
<div class="card">
	<div class="card-body">
		<a class="btn btn-fill btn-info" href="index.php?Act=cat&amp;joinstatus=All"><img src="../images/close.gif" border="0" alt="" />&nbsp;
			<b><?=$lang_affiliate_pgms_category?></b></a>
		<a class="btn btn-fill btn-info" href="index.php?Act=Affiliates&amp;joinstatus=All"><img src="../images/close.gif" border="0" alt="" />&nbsp;
			<b><?=$lang_affiliate_pgms_all?></b></a>
		<a class="btn btn-fill btn-info" href="index.php?Act=MyAffiliates&amp;joinstatus=myprograms"><img src="../images/close.gif" border="0" alt="" />&nbsp;
		<b><?=$lang_affiliate_pgms_my?></b></a>	
	</div>
</div>    
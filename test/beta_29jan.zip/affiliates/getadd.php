<div class="row"> 
	<div class="col-md-12">
		<div class="card"> 
			<div class="card-body">
				<div class="row">
					<div class="col-md-6 text-left">
						<p>Please select what link type you require ?</p>
					</div>
					<div class="col-md-6 text-right">
						<a href="index.php?Act=sub_id_list">&laquo;<?=$lang_home_manage_subid?>&raquo;</a>			
					</div>
				</div>
			</div>	
		</div>	 
	</div>	  
</div>   
	 
<div class="row"> 
	<div class="col-md-6"> 
		<div class="card regular-table-with-color">
			<div class="card-body table-full-width table-responsive">
				
				<table class="table table-hover">
					<thead> 
						<tr>
							<th><?=$lang_home_text?></th>
							<!--<th><?=$lang_home_banner?></th>-->
							<!--<th><?/*=$lang_home_flash?></th>
							<th><?=$lang_home_html?></th>
							<th><?=$lang_home_popup?></th>
							<th><?=$lang_home_texttemplate*/?></th>-->
						</tr> 
					</thead>
					<tbody>
						<tr>  
							<td><?=$lang_text_help?></td>
						<!--	<td><?=$lang_banner_help?></td>-->
							<!--<td><?/*=$lang_flash_help?></td>
							<td><?=$lang_html_help?></td>
							<td><?=$lang_popup_help?></td>
							<td><?=$laddban_TemplateAdtext*/?></td>-->
						</tr> 
						<tr>
							<td><a class="btn btn-round btn-info" href="index.php?Act=gettext">Text Link</a></td>
							<!--<td><a class="btn btn-round btn-lg" href="index.php?Act=getbanner">Banner Links</a></td>-->
							<!--<td><a href="index.php?Act=getflash"><img src='images/flash.jpg' border='0' alt=""/></a></td>
							<td><a href="index.php?Act=gethtml"><img src='images/html.jpg' border='0' alt=""/></a></td>
							<td><a href="index.php?Act=getpopup"><img src='images/pop.jpg' border='0' alt=""/></a></td>
							<td><a href="index.php?Act=gettextnew"><img src='images/temp_text.jpg' border='0' alt=""/></a></td>-->
						</tr>
					</tbody>	
				</table>
			</div>	
		</div>	 
	</div>	 
	<div class="col-md-6">
		<div class="card regular-table-with-color">
			<div class="card-body table-full-width table-responsive">
				<table class="table table-hover">
					<thead> 
						<tr>
							<th><?=$lang_home_banner?></th>
							<!--<th><?/*=$lang_home_flash?></th>
							<th><?=$lang_home_html?></th>
							<th><?=$lang_home_popup?></th>
							<th><?=$lang_home_texttemplate*/?></th>-->
						</tr> 
					</thead>
					<tbody>
						<tr>
							<td><?=$lang_banner_help?></td>
							<!--<td><?/*=$lang_flash_help?></td>
							<td><?=$lang_html_help?></td>
							<td><?=$lang_popup_help?></td>
							<td><?=$laddban_TemplateAdtext*/?></td>-->
						</tr>  
						<tr>
							<td><a class="btn btn-round btn-info" href="index.php?Act=getbanner">Banner Links</a></td>
							<!--<td><a href="index.php?Act=getflash"><img src='images/flash.jpg' border='0' alt=""/></a></td>
							<td><a href="index.php?Act=gethtml"><img src='images/html.jpg' border='0' alt=""/></a></td>
							<td><a href="index.php?Act=getpopup"><img src='images/pop.jpg' border='0' alt=""/></a></td>
							<td><a href="index.php?Act=gettextnew"><img src='images/temp_text.jpg' border='0' alt=""/></a></td>-->
						</tr>
					</tbody>	
				</table>
			</div>	
		</div>	 
	</div>	 
</div>   
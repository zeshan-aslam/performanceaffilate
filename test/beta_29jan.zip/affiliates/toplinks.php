 <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0" class="tablehdbdr" style="BORDER-COLLAPSE: collapse; TEXT-ALIGN: center">
  <tr>
    <td width="19" class="tdhead">
      <p align="center">&nbsp;</p></td>
    <td class="tdhead">
      <p align="center"><span lang='bg'><b><?=$toplinks_banner?></b></span></p></td>
    <!--  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	    <td width="343" class="tdhead">

                                                    <p align="center"><b>Flash</b></p></td>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
  </tr>
  <tr>
    <td width="19" valign="top" style="TEXT-ALIGN: left">
      <p align="center">&nbsp;</p></td>
    <td valign="top" class="grid1">
      <p align="justify" style="TEXT-ALIGN: left"><?=$toplinks_text?>&nbsp; </p></td>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        <td width="343" valign="top" class="grid1">
        <p style="TEXT-ALIGN: left" align="center">Get<span lang='bg'> your Flash ads</span>
                        from <span lang='bg'>&nbsp;here.
                        </span>Copy the text and past
                  it on your site.</p>        </td>
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
  </tr>
  <tr>
    <td width="19" class="grid1">
      <p align="center">&nbsp;</p></td>
    <td class="grid1">
      <p align="center"><a href="index.php?Act=getrotator&amp;catid=<?=$catid?>"></a></p></td>
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        <td width="343" class="grid1">

                                                    <p align="center"><a href="index.php?Act=getflash_rotator&catid=<?=$catid?>"><IMG height=34 alt="Flash Bannner Rotator" src="images/grapgicd.gif" width=135 border="0" ></a></p></td>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
  </tr>
  <tr>
    <td height="35" colspan="3" class="textred">
      <p><?=$toplinks_text2?></p></td>
  </tr>
  <tr>
    <td height="17" colspan="3" class="tdhead">
      <p>&nbsp;</p></td>
  </tr>
</table>
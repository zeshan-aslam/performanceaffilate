<table cellpadding="0" cellspacing="0"  width="100%"   class="tablewbdr">

  <tr>
    <td width="100%" class="tdhead" align="right">
    [<a href="index.php?Act=paymentlist"><?=$lang_paymentlist?></a>]
    [<a href="index.php?Act=manual_payments"><?=$lang_manual_payments?></a>]

     </tr>
</table>
<div class="sidebar" data-color="blue" data-image="../public/assets/img/sidebar-4.jpg">
	<div class="sidebar-wrapper">
		<div class="logo">
			<a href="#" class="simple-text logo-mini">
				A
			</a>
			<a href="#" class="simple-text logo-normal">
				AVAZ
			</a>
		</div>
		<div class="user">
			<div class="photo">
				<img src="https://www.slaterheelis.co.uk/wp-content/uploads/2014/10/avatar-man-no-text-grey.jpg" />
			</div>
			<div class="info ">
				<a data-toggle="collapse" href="#" class="collapsed">
					<span><?=$_SESSION['AFFILIATENAME']?>
					</span>
				</a>
				<div class="collapse" id="collapseExample">
				</div>
			</div>
		</div>
		<ul class="nav">
			<?php include"links.php";?>
		</ul>
	</div>
</div>
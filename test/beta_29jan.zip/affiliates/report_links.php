<div class="card">
	<div class="card-body"> 
		<a class="btn btn-fill btn-info" href="index.php?Act=daily"><?=$lang_home_daily?></a>
		<a class="btn btn-fill btn-info" href="index.php?Act=forperiod"><?=$lang_home_forperiod?></a>
		<a class="btn btn-fill btn-info" href="index.php?Act=TransReport"><?=$lang_home_transaction?></a>
		<!--<a class="btn btn-fill btn-info" href="index.php?Act=LinkReport"><?/*=$lang_home_links?></a>
		<a class="btn btn-fill btn-info" href="index.php?Act=productReport"><?=$lang_pdt_report*/?></a>-->
		<a class="btn btn-fill btn-info" href="index.php?Act=subid_report"><?=$lang_subid_report?></a>	 
		<!--<a class="btn btn-fill btn-info" href="index.php?Act=referral"><?=$lang_referral_report?></a>-->
	</div> 
</div>  	
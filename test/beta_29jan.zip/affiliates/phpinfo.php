<?php

echo $dsfdsf = phpinfo();
?>
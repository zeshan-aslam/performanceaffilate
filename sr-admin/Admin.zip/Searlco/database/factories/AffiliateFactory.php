<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Affiliate;
use Faker\Generator as Faker;

$factory->define(Affiliate::class, function (Faker $faker) {
    return [
        //
    ];
});

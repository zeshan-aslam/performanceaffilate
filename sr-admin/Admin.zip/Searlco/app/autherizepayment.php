<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class autherizepayment extends Model
{
    public  $table='autherizepayment';
}

<?php

namespace App\Http\Controllers;

use App\Merchant;
use App\Login;
use App\User;
use App\Utilities\SiteHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use stdClass;

class MerchantController extends Controller
{


    public function __construct()
    {
        $this->middleware(['auth', 'role:superadministrator']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {



        $pending = DB::table('partners_transaction', 't')
            ->join('partners_joinpgm as j', 't.transaction_joinpgmid', '=', 'j.joinpgm_id')
            ->join('partners_merchant as m', 'j.joinpgm_merchantid', '=', 'm.merchant_id')


            ->where('t.transaction_status', 'pending')
            ->count();


        $merchants = DB::table('partners_merchant')->get();
        $approved = DB::table('partners_merchant')
            ->where('merchant_status', 'approved')
            ->count();
        $waiting = DB::table('partners_merchant')
            ->where('merchant_status', 'waiting')
            ->count();
        $suspend = DB::table('partners_merchant')
            ->where('merchant_status', 'suspend')
            ->count();
        $NP = DB::table('partners_merchant')
            ->where('merchant_status', 'NP')
            ->count();
        $empty = DB::table('partners_merchant')
            ->where('merchant_status', 'empty')
            ->count();


        $loginData = DB::table('partners_login')->where(['login_flag' => 'm'])->get();

        $adjustMoneydata = DB::table('merchant_pay')->get();

        return view('merchant.index', compact('merchants', 'pending', 'approved', 'waiting', 'suspend', 'NP', 'empty', 'loginData', 'adjustMoneydata'));

        // dd( $merchants->attributesToArray());
    }
    public function getMerchants()
    {


        $data=array();
        $merchants = DB::table('partners_merchant','m')
        ->join('merchant_pay as p','m.merchant_id','=','p.pay_merchantid')
        ->select('m.*','p.*')
        ->get();
        $i=0;
        foreach($merchants as $row){
            $data[$i]['merchant_id']=$row->merchant_id;
            $data[$i]['merchant_status']=$row->merchant_status;
            $data[$i]['merchant_company']=$row->merchant_company;
            $data[$i]['merchant_firstname']=$row->merchant_firstname;
            $data[$i]['merchant_lastname']=$row->merchant_lastname;
            $data[$i]['merchant_pgmapproval']=$row->merchant_pgmapproval;
            $data[$i]['merchant_date']=$row->merchant_date;
            $data[$i]['pay_amount']=$row->pay_amount;
            $data[$i]['merchant_invoiceStatus']=$row->merchant_invoiceStatus;
            $data[$i]['pending_amount']=SiteHelper::GetPaymentPendingDetails($row->merchant_id,1);
            $data[$i]['merchant_address']=$row->merchant_address;
            $data[$i]['merchant_country']=$row->merchant_country;
            $data[$i]['merchant_city']=$row->merchant_city;
            $data[$i]['merchant_phone']=$row->merchant_phone;
            $data[$i]['merchant_category']=$row->merchant_category;
            $data[$i]['merchant_fax']=$row->merchant_fax;
            $data[$i]['merchant_type']=$row->merchant_type;
            $data[$i]['merchant_currency']=$row->merchant_currency;
            $data[$i]['merchant_zip']=$row->merchant_zip;
            $data[$i]['merchant_taxId']=$row->merchant_taxId;
            $data[$i]['merchant_orderId']=$row->merchant_orderId;
            $data[$i]['merchant_saleAmt']=$row->merchant_saleAmt;
            $data[$i]['merchant_state']=$row->merchant_state;
            
 

            $i++;

        }

        return response()->json([
            'message' => 'Data Found',
            'code' => '200',
            'data' => $data,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Merchant  $merchant
     * @return \Illuminate\Http\Response
     */
    public function getMerchant($id)
    {

        return  DB::table('partners_login','L')
        ->join('partners_merchant as M',function($join) use ($id){
            $join->on('L.login_id','=','M.merchant_id')
            ->where('L.login_flag','=','m')
            ->where('L.login_id','=',$id);
        }
        )->select('L.*','M.*')->first();
    }
    public function show(Merchant $merchant, $id)
    {

        $merchant = DB::table('partners_merchant')->where(['merchant_id' => $id])->first();
      
        return response()->json($merchant);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Merchant  $merchant
     * @return \Illuminate\Http\Response
     */
    public function edit(Merchant $merchant, $id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Merchant  $merchant
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Merchant $merchant, $id)
    {
      
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Merchant  $merchant
     * @return \Illuminate\Http\Response
     */
    public function destroy(Merchant $merchant, $id)
    {
        $toDelete = DB::table('partners_merchant')->where('merchant_id', $id)->delete();
      
        return redirect()->route('Merchant.index')->with('success', 'Merchant deleted!');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Merchant  $merchant
     * @return \Illuminate\Http\Response
     */
    public function changePasswordForm($id)
    {

        $loginData = DB::table('partners_login')->where(['login_id' => $id, 'login_flag' => 'm'])->first();

        return response()->json($loginData);
    }
    public function changePassword(Request $request)
    {
        $id = $request->id;
        $data = Login::where(['login_id' => $id, 'login_flag' => 'm'])
            ->limit(1)
            ->update(array('login_password' => $request->password));

            SiteHelper::sendMerchantMail($this->getMerchant($id),'Change Merchant Password');

        return response()->json($data);
    }
    public function adjustMoneyForm($id)
    {

        $data = DB::table('merchant_pay')->where(['pay_merchantid' => $id])->first();

        return response()->json($data);
    }
    public function adjustMoney(Request $request)
    {

        $id = $request->id;


        $data = DB::table('merchant_pay')->where(['pay_merchantid' => $id])->first();

        if ($request->action == 'add') {
            $data->pay_amount = $data->pay_amount + (float)$request->pay_amount;
            $res = DB::table('merchant_pay')
                ->where(['pay_merchantid' => $id])
                ->limit(1)
                ->update(array('pay_amount' => $data->pay_amount));
               

            return response()->json($res);
        }


        if ($request->action == 'deduct') {


            $data->pay_amount = $data->pay_amount - (float)$request->pay_amount;
            $res = DB::table('merchant_pay')
                ->where(['pay_merchantid' => $id])
                ->limit(1)
                ->update(array('pay_amount' => $data->pay_amount));

            return response()->json($res);
        }
    }

    public function paymentHistoryForm($id)
    {
        session(['id'=> $id]);
        $data = DB::table('partners_transaction', 't')
            ->join('partners_joinpgm as j', function ($join) {
                $join->on('t.transaction_joinpgmid', '=', 'j.joinpgm_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->join('partners_merchant as m', function ($join) {
                $join->on('j.joinpgm_merchantid', '=', 'm.merchant_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->join('partners_affiliate as a', function ($join) {
                $join->on('j.joinpgm_affiliateid', '=', 'a.affiliate_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->select('t.*', 'j.*', 'm.*', 'a.*')
            ->where('t.transaction_dateofpayment', '<>', '0000-00-00')
            ->where('t.transaction_status', '<>', 'pending')
            ->orderby('t.transaction_dateofpayment', 'DESC')
            ->get();

        $merchants = DB::table('partners_adjustment', 'a')
            ->join('partners_merchant as m', function ($join) {
                $join->on('a.adjust_memberid', '=', 'm.merchant_id')
                    ->where('a.adjust_memberid', '=', session('id'))
                    ->where('a.adjust_flag', '=', 'm');
            })
            ->select('a.*', 'm.*')
            ->orderby('a.adjust_date', 'DESC')
            ->get();

  
        return view('merchant.paymenthistory', compact('data', 'merchants','id'));

    }
    public function paymentHistoryByDate(Request $request, $id)
    {
       
        session(['id'=> $id]);
        $data = DB::table('partners_transaction', 't')
            ->join('partners_joinpgm as j', function ($join) {
                $join->on('t.transaction_joinpgmid', '=', 'j.joinpgm_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->join('partners_merchant as m', function ($join) {
                $join->on('j.joinpgm_merchantid', '=', 'm.merchant_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->join('partners_affiliate as a', function ($join) {
                $join->on('j.joinpgm_affiliateid', '=', 'a.affiliate_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->select('t.*', 'j.*', 'm.*', 'a.*')
            ->where('t.transaction_dateofpayment', '<>', '0000-00-00')
            ->where('t.transaction_status', '<>', 'pending')
            ->whereBetween('transaction_dateoftransaction', array($request->From, $request->To))
            ->orderby('t.transaction_dateofpayment', 'DESC')
            ->get();

        $merchants = DB::table('partners_adjustment', 'a')
            ->join('partners_merchant as m', function ($join) {
                $join->on('a.adjust_memberid', '=', 'm.merchant_id')
                    ->where('a.adjust_memberid', '=', session('id'))
                    ->where('a.adjust_flag', '=', 'm');
            })
            ->select('a.*', 'm.*')
            ->whereBetween('a.adjust_date', array($request->From, $request->To))
            ->orderby('a.adjust_date', 'DESC')
            ->get();



            return view('merchant.paymenthistory', compact('data', 'merchants','id'));


    }

    public function transactionForm($id)
    {
        session(['id'=> $id]);
        $data = DB::table('partners_transaction', 't')
            ->join('partners_joinpgm as j', function ($join) {
                $join->on('t.transaction_joinpgmid', '=', 'j.joinpgm_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->join('partners_merchant as m', function ($join) {
                $join->on('j.joinpgm_merchantid', '=', 'm.merchant_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->join('partners_affiliate as a', function ($join) {
                $join->on('j.joinpgm_affiliateid', '=', 'a.affiliate_id')
                    ->where('j.joinpgm_merchantid', '=', session('id'));
            })
            ->select('t.*', 'j.*', 'm.*', 'a.*')
            ->where('t.transaction_dateofpayment', '<>', '0000-00-00')
            ->where('t.transaction_status', '<>', 'pending')
            ->orderby('t.transaction_dateofpayment', 'DESC')
            ->get();


            return view('merchant.transaction',compact('data','id'));

    }
    public function suspendMerchant(Request $request)
    {

        $data = DB::table('partners_merchant')
            ->where(['merchant_id' => $request->id])
            ->limit(1)
            ->update(array('merchant_status' => 'suspend'));
            if($data){
                SiteHelper::sendMerchantMail($this->getMerchant($request->id),'Suspend Merchant');
               
            }
            return response()->json($data);
       
    }
    public function approveMerchant(Request $request)
    {

        $data = DB::table('partners_merchant')
            ->where(['merchant_id' => $request->id])
            ->limit(1)
            ->update(array('merchant_status' => 'approved'));
            if( $data){
                SiteHelper::sendMerchantMail($this->getMerchant($request->id),'Approve Merchant');
            }
        return response()->json($data);
    }

    public function pgmApprovelMerchant(Request $request)
    {
        $id = $request->id;
        if (DB::table('partners_merchant')->where(['merchant_id' => $id, 'merchant_pgmapproval' => 'automatic'])->exists()) {
            $data = DB::table('partners_merchant')
                ->where(['merchant_id' => $id])
                ->limit(1)
                ->update(array('merchant_pgmapproval' => 'manual'));
            return response()->json($data);
        } else {
            $data = DB::table('partners_merchant')
                ->where(['merchant_id' => $id])
                ->limit(1)
                ->update(array('merchant_pgmapproval' => 'automatic'));
            return response()->json($data);
        }
    }
    public function activateInvoiceStatusMerchant(Request $request)
    {
        $id = $request->id;
        $today            = date("Y-m-d");
        DB::table('partners_invoicestat')->insert(
            ['invoice_merchantid' => $id, 'invoice_date' => $today, 'invoice_status' => 'active']
        );
        $data = DB::table('partners_merchant')
            ->where(['merchant_id' => $id])
            ->limit(1)
            ->update(array('merchant_invoiceStatus' => 'active'));
        return response()->json($data);
    }
    public function DeActivateInvoiceStatusMerchant(Request $request)
    {
        $id = $request->id;
        $today            = date("Y-m-d");
        DB::table('partners_invoicestat')
            ->insert(
                ['invoice_merchantid' => $id, 'invoice_date' => $today, 'invoice_status' => 'inactive']
            );
        $data = DB::table('partners_merchant')
            ->where(['merchant_id' => $id])
            ->limit(1)
            ->update(array('merchant_invoiceStatus' => 'inactive'));
        return response()->json($data);
    }
    public function removeMerchantForm($id)
    {
        return view('merchant.remove', compact('id'));
    }
    public function removeMerchant(Request $request)
    {
      
        $ret=array();
        $id = $request->id;
        $ret[] = DB::table('partners_merchant')->where('merchant_id', '=', $id)->delete();
        $ret[] =  DB::table('partners_login')->where('login_id', '=', $id)->delete();
        $ret[] = DB::table('merchant_pay')->where('pay_merchantid', '=', $id)->delete();
        $ret[] = DB::table('partners_adjustment')->where('adjust_memberid', '=', $id)->delete();
        $ret[] = DB::table('partners_fee')->where('adjust_memberid', '=', $id)->delete();
        if (!in_array(0,$ret)) {
            $data = 1;
          
        } else {
            $data = 0;
        }


        return response()->json($data);
    }
    public function loginMerchant(Request $request, $id)
    {
        session_start();
        $data = DB::table("partners_merchant")
            ->where('merchant_id', $id)
            ->get();
        $pay = DB::table("merchant_pay")
            ->where('pay_merchantid', $id)
            ->get();

        if (count($data) > 0 && count($pay) > 0) {
            unset($_SESSION['MERCHANTID']);
            unset($_SESSION['MERCHANTNAME']);
            unset($_SESSION['MERCHANTBALANCE']);
            $_SESSION['MERCHANTID'] = $data[0]->merchant_id;
            $_SESSION['MERCHANTNAME'] = stripslashes($data[0]->merchant_firstname) . " " . stripslashes($data[0]->merchant_lastname);
            $_SESSION['MERCHANTBALANCE'] = $pay[0]->pay_amount;

            echo  $_SESSION['MERCHANTID'] . $_SESSION['MERCHANTNAME'] . $_SESSION['MERCHANTBALANCE'];

            return redirect("https://searlco.net/merchants/index.php?Act=home");
        } else {
            return "Error Logging in ";
        }
    }
}

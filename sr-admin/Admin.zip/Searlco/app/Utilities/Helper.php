<?php

namespace App\Utilities;

use Illuminate\Support\Facades\DB;

class Helper
{
    public static function test(){
        return "Test Helper";
    }

}